<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'username' => 'required',
            'client_id' => 'required',
            'contracts.1.name' => 'required',
            'contracts.1.contract' => 'required',
            'contracts.2.name' => 'required',
            'contracts.2.contract' => 'required',
            'contracts.3.name' => 'required',
            'contracts.3.contract' => 'required',
            'firstname' => 'required',
            'lastname' => 'required',
            'dni' => 'required',
            'phone' => 'required',
            'email' => 'required',
            'address' => 'required',
            'number' => 'required',
            'postal_code' => 'required',
        ];
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'username.required' => 'El usuario es requerido',
            'client_id.required' => 'A numero de cliente es requerido',
            'contracts.1.name.required' => 'El nombre de contrato Nro 1 es requerido',
            'contracts.1.contract.required' => 'El numero de contrato Nro1 es requerido',
            'contracts.2.name.required' => 'El nombre de contrato Nro2 es requerido',
            'contracts.2.contract.required' => 'El numero de contrato Nro2 es requerido',
            'contracts.3.name.required' => 'El nombre de contrato Nro3 es requerido',
            'contracts.3.contract.required' => 'El numero de contrato Nro3 es requerido',
            'firstname.required' => 'El nombre es requerido',
            'lastname.required' => 'El apellido es requerido',
            'dni.required' => 'El DNI es requerido',
            'phone.required' => 'El telefono es requerido',
            'email.required' => 'El email es requerido',
            'address.required' => 'La direccion es requerida',
            'number.required' => 'El numero de direccion es requerido',
            'postal_code.required' => 'El codigo postal es requerido',

        ];
    }
}
