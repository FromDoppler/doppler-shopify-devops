<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SetupRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'username' => 'required',
            'password' => 'required',
            'client_id' => 'required',
            'nombre_1' => 'required',
            'contrato_1' => 'required',
            'nombre_2' => 'required',
            'contrato_2' => 'required',
            'nombre_3' => 'required',
            'contrato_3' => 'required',
            'firstname' => 'required',
            'lastname' => 'required',
            'dni' => 'required',
            'phone' => 'required',
            'email' => 'required',
            'address' => 'required',
            'number' => 'required',
            'postal_code' => 'required',
        ];
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'username.required' => 'El usuario es requerido',
            'password.required' => 'La contraseña es requerida',
            'client_id.required' => 'A numero de cliente es requerido',
            'nombre_1.required' => 'El nombre de contrato Nro 1 es requerido',
            'contrato_1.required' => 'El numero de contrato Nro1 es requerido',
            'nombre_2.required' => 'El nombre de contrato Nro2 es requerido',
            'contrato_2.required' => 'El numero de contrato Nro2 es requerido',
            'nombre_3.required' => 'El nombre de contrato Nro3 es requerido',
            'contrato_3.required' => 'El numero de contrato Nro3 es requerido',
            'firstname.required' => 'El nombre es requerido',
            'lastname.required' => 'El apellido es requerido',
            'dni.required' => 'El DNI es requerido',
            'phone.required' => 'El telefono es requerido',
            'email.required' => 'El email es requerido',
            'address.required' => 'La direccion es requerida',
            'number.required' => 'El numero de direccion es requerido',
            'postal_code.required' => 'El codigo postal es requerido',
        ];
    }
}
