<?php

namespace App\Http\Controllers;

use App\Services\ShopifyService;
use Illuminate\Http\Request;

/**
 * Class OrderController
 * @package App\Http\Controllers
 */
class ShopifyController extends Controller
{

    /**
     * @param Request $request
     */
    public function getOrder(Request $request)
    {
        /** @var ShopifyService $service */
        $service = app(ShopifyService::class);
        $orders = $service->getOrder()->paginate(5);
        return view('andreani_config', compact('orders'));
    }
}
