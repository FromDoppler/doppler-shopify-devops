<?php

namespace App\Http\Controllers;

use App\Http\Resources\MeShopResource;
use App\Services\DopplerService;
use App\Services\ShopifyService;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redirect;
use App\Http\Resources\ProductResource;

/**
 * Class DopplerController
 * @package App\Http\Controllers
 */
class ConfirmationController extends Controller
{
    public function index(Request $request)
    {
    	$params = $request->all();
        list($current_lang, $secundary_lang) = $this->getLang($params);
        App::setlocale($current_lang);
        return view('confirmation', compact('current_lang', 'secundary_lang'));
    }
}
