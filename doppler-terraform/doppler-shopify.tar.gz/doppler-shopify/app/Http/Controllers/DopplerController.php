<?php

namespace App\Http\Controllers;

use App\Http\Resources\MeShopResource;
use App\Services\DopplerService;
use App\Services\ShopifyService;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\ProductResource;
use App\Models\User;
use App\Models\ConfigDoppler;

use Lcobucci\JWT\Builder;
use Lcobucci\JWT\Signer\Key;
use Lcobucci\JWT\Signer\Rsa\Sha256;
use Lcobucci\JWT\Parser;

/**
 * Class DopplerController
 * @package App\Http\Controllers
 */
class DopplerController extends Controller
{
    /**
     * @param Request $request
     * @return Application|Factory|View
     */
    public function setup(Request $request)
    {
        /** @var DopplerService $service */
        $service = app(DopplerService::class);
        if(!$service->isConfigured()) {
            $step = $service->getStepSetup();
            if (!empty($step)) {
                if ($step == 'setupStepThree') {
                    $subscribersList = [];
                    $isSetup = true;
                    try {
                      $subscribersList = $service->getSubscribersList();
                      return view($step, compact('subscribersList','isSetup'));
                    } catch (\Exception $e) {
                      return view($step, compact('subscribersList','isSetup'))->withErrors('Error to get lists.');
                    }
                } elseif ($step == 'setupStepFour') {
                    $custom_field_doppler = $service->getCustomFields();
                    $field_mapping = $service->getFiedlMapping();
                    $integrationConfig = Config::get('external')['integration'];
                    $field_mapping_shopify = $integrationConfig['shopify']['customerFields'];
                    $isSetup = true;
                    return view('setupStepFour', compact('field_mapping','field_mapping_shopify', 'custom_field_doppler', 'isSetup'));
                }
                return view($step);
            }
            return view('setupStepOne');
        }
        $dopplerConfig = $service->getDopplerConfig();

        return view('doppler', compact('dopplerConfig'));
    }

    /**
     * @param Request $request
     * @return Application|Factory|View
     */
    public function setupStepTwo(Request $request)
    {
        return view('setupStepTwo');
    }

    /**
     * @param Request $request
     * @return Application|Factory|View
     */
    public function setupApp(Request $request)
    {
        /** @var DopplerService $service */
        $service = app(DopplerService::class);
        try {
            $service->setupApp($request->all());
        } catch (\Exception $e) {
            return Redirect::back()->withErrors($e->getMessage());
        }
        $subscribersList = $service->getSubscribersList();
        $isSetup = true;
        $listConfigured = false;
        return view('setupStepThree', compact('subscribersList','isSetup', 'listConfigured'));
    }

    /**
     * @param Request $request
     * @return Application|Factory|View
     */
    public function createSubscriptionList(Request $request)
    {
        $params = $request->all();
        Log::info(__METHOD__ . ' - createSubscriptionList ', [
            'params' => $params,
        ]);
        /** @var DopplerService $service */
        $service = app(DopplerService::class);
        $resp = null;
        try {
            $resp = $service->createSubscribersList($params);
        } catch (\Exception $e) {
            return Redirect::back()->withErrors($e->getMessage());
        }

        $subscribersList = [];
        $error_message = null;
        try {
          $subscribersList = $service->getSubscribersList();
        } catch (\Exception $e) {
          $error_message = 'Error to get lists.';
        }

        $isSetup = true;
        $listConfigured = true;
        if (empty($params['isSetup'])) {
            $isSetup = false;
        }
        if (empty($params['listConfigured'])) {
            $listConfigured = false;
        }

        if((isset($resp) && isset($resp['errorCode'])) || isset($error_message)) {
          return view('setupStepThree', compact('subscribersList','isSetup', 'listConfigured'))->withErrors(isset($resp['title']) ? $resp['title'] : $error_message );
        } else {
          return view('setupStepThree', compact('subscribersList','isSetup', 'listConfigured'));
        }
    }

    /**
     * @param Request $request
     * @return Application|Factory|View
     */
    public function setCurrentSubscriberList(Request $request)
    {
        $params = $request->all();
        if(isset($params['list'])) {
          $params = json_decode($params['list'], true);
          /** @var DopplerService $service */
          $service = app(DopplerService::class);
          $service->setCurrentSubscriberList($params);
          $custom_field_doppler = $service->getCustomFields();
          $field_mapping = $service->getFiedlMapping();
          $integrationConfig = Config::get('external')['integration'];
          $field_mapping_shopify = $integrationConfig['shopify']['customerFields'];
          $isSetup = true;
          return view('setupStepFour', compact('field_mapping','field_mapping_shopify', 'custom_field_doppler', 'isSetup'));
        } else {
          //return Redirect::back()->withErrors('Select a list to continue');
          $subscribersList = [];
          $isSetup = true;
          $listConfigured = false;

          try {
            $service = app(DopplerService::class);
            $subscribersList = $service->getSubscribersList();

            return view('setupStepThree', compact('subscribersList','isSetup', 'listConfigured'))->withErrors('Select a list to continue');
          } catch (\Exception $e) {
            return view('setupStepThree', compact('subscribersList','isSetup', 'listConfigured'))->withErrors($e->getMessage());
          }
        }
    }

    /**
     * @param Request $request
     * @return Application|Factory|View
     */
    public function setupStepFour(Request $request)
    {
      try {
        $params = $request->all();
        $fields = json_decode($params['fields'], true);
        /** @var DopplerService $service */
        $service = app(DopplerService::class);
        $service->setFiedlMapping($fields);
        $service->synchronizeCustomers($fields);
        return response([
            'status' => 'OK'
        ]);
      } catch (\Exception $e) {
        return Redirect::back()->withErrors($e->getMessage());
      }
    }

    /**
     * @param Request $request
     * @return Application|Factory|View
     */
    public function dopplerIndex(Request $request)
    {
        /** @var DopplerService $service */
        $service = app(DopplerService::class);
        $dopplerConfig = $service->getDopplerConfig();
        $subscribersList = $service->getSubscribersList();
        $listConfigured = true;
        $find = false;

        if(!is_array($subscribersList)){
          return view('doppler', compact('dopplerConfig'))->withErrors($subscribersList['title']);
        } else {
          foreach ($subscribersList as $item) {
              if ($dopplerConfig['list_name'] == $item->name) {
                  $find = true;
              }
          }
          if (!$find) {
              $isSetup = false;
              $listConfigured = false;
              return view('setupStepThree', compact('subscribersList','isSetup', 'listConfigured'));
          }
          return view('doppler', compact('dopplerConfig'));
        }
    }


    /**
     * @param Request $request
     * @return Application|Factory|View
     */
    public function selectFieldDoppler(Request $request)
    {
        $params = $request->all();
        $type = $params['type'];
        $fields_doppler = [];
        if (isset($params['fieldMapping']) && !empty($params['fieldMapping'])) {
            $fields_doppler = $this->getDopplerField($params['fieldMapping']);
        }
        /** @var DopplerService $service */
        $service = app(DopplerService::class);
        $custom_field_doppler = $this->cleanCustomFields($service->getCustomFields(), $fields_doppler);
        $select_field_dooppler = [];
        foreach ($custom_field_doppler as $field_dooppler) {
            if ($field_dooppler->type == $type) {
                $select_field_dooppler[] = (array)$field_dooppler;
            }
        }
        return $select_field_dooppler;
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function synchronizeCustomers(Request $request)
    {
        /** @var DopplerService $service */
        $service = app(DopplerService::class);
        $response = $service->synchronizeCustomersByDb();
        return response()->json(['success' => 'success', 'data' => $response, 200]);
    }

    /**
     * @param Request $request
     * @return Application|Factory|View
     */
    public function replaceList(Request $request)
    {
        /** @var DopplerService $service */
        $service = app(DopplerService::class);
        $subscribersList = $service->getSubscribersList();
        $isSetup = false;
        $listConfigured = true;

        if(isset($subscribersList['errorCode']) || (isset($subscribersList['title'])) ){
          return view('setupStepThree', compact('subscribersList','isSetup', 'listConfigured'))->withErrors($subscribersList['title']);
        } else {
          return view('setupStepThree', compact('subscribersList','isSetup', 'listConfigured'));
        }
    }

    /**
     * @param Request $request
     * @return Application|Factory|View
     */
    public function fieldsMapping(Request $request)
    {
        /** @var DopplerService $service */
        $service = app(DopplerService::class);
        try {
          $custom_field_doppler = $service->getCustomFields();

          if(isset($custom_field_doppler['errorCode'])) {
            return Redirect::back()->withErrors($custom_field_doppler['title']);
          }
        } catch (\Exception $e) {
          return Redirect::back()->withErrors($e->getMessage());
        }
        $field_mapping = $service->getFiedlMapping();
        $integrationConfig = Config::get('external')['integration'];
        $field_mapping_shopify = $integrationConfig['shopify']['customerFields'];
        $isSetup = false;

        //validate list
        $list_valid = $service->validateCurrentSubscriberListId();

        return view('setupStepFour', compact('field_mapping','field_mapping_shopify', 'custom_field_doppler', 'isSetup', 'list_valid'));
    }

    /**
     * @param Request $request
     * @return Application|Factory|View
     */
    public function syncAndReplaceList(Request $request)
    {
      $params = $request->all();
      if(isset($params['list'])) {
        try {
          $params = json_decode($params['list'], true);
          /** @var DopplerService $service */
          $service = app(DopplerService::class);
          $service->setCurrentSubscriberList($params);
          $service->synchronizeCustomersByDb();
          return response([
              'status' => 'OK'
          ]);
        } catch (\Exception $e) {
          return response([
              'status' => 'ERROR',
              'errorMessage' => $e->getMessage()
          ]);
        }
      } else {

        return response([
            'status' => 'ERROR',
            'errorMessage' => 'Select a list to continue'
        ]);
      }

    }

    private function getDopplerField($fieldMapping)
    {
        $fieldsDoppler = [];
        foreach ($fieldMapping as $field) {
            $fieldsDoppler[] = $field['doppler_field'];
        }
        return $fieldsDoppler;
    }

    private function cleanCustomFields(array $custom_field_doppler, array $fields_doppler)
    {
        $custom_field = [];
        array_push($fields_doppler, 'EMAIL');
        foreach ($custom_field_doppler as $field) {
            if (!in_array($field->name, $fields_doppler)) {
                $custom_field[] = $field;
            }
        }
        return $custom_field;
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function webhookSyncCoustomer(Request $request)
    {
      try {
        $params = $request->all();
        Log::info(__METHOD__ . ' - webhookSyncCoustomer ', [
            'params' => $params,
        ]);
        /** @var DopplerService $service */
        $service = app(DopplerService::class);
        $service->synchronizeCustomersByDb($params);
      } catch (\Exception $e) {
        Log::info(__METHOD__ . ' - webhookSyncCoustomerError ', [
            'error' => $e->getMessage(),
        ]);
      }
      return response()->json(['success' => 'success'], 200);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function webhookAppUninstalled(Request $request)
    {
      $params = $request->all();
      Log::info(__METHOD__ . ' - webhookAppUninstalled ', [
          'params' => $params,
      ]);

      try {

        /** @var DopplerService $service */
        $service = app(DopplerService::class);
        $service->deleteIntegrations();
        $service->webhookAppUninstalled($params);

      } catch (\Exception $e) {
        Log::info(__METHOD__ . ' - webhookAppUninstalledError ', [
            'error' => $e->getMessage(),
        ]);
      }

      return response()->json(['success' => 'success'], 200);
    }

    /**
     * @param Request $request
     * @return ProductResource
     */
    public function getProducts(Request $request)
    {
        $params = $request->all();
        Log::info(__METHOD__ . ' - getProducts ', [
            'params' => $params,
        ]);
        /** @var ShopifyService $service */
        $service = app(ShopifyService::class);
        $products = $service->getProducts($params);
        return new ProductResource($products);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function getWebhooks(Request $request)
    {
        $params = $request->all();
        Log::info(__METHOD__ . ' - getWebhooks ', [
            'params' => $params,
        ]);
        /** @var ShopifyService $service */
        $service = app(ShopifyService::class);
        $webhooks = $service->getWebhooks($params);
        return response()->json(['webhooks' => $webhooks, 200]);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function setWebhooks(Request $request)
    {
        $params = $request->all();
        Log::info(__METHOD__ . ' - setWebhooks ', [
            'params' => $params,
        ]);
        /** @var ShopifyService $service */
        $service = app(ShopifyService::class);
        $webhooks = $service->setWebhooks($params);
        return response()->json(['webhooks' => $webhooks, 200]);
    }

    /**
     * @param Request $request
     * @return MeShopResource
     */
    public function meShop(Request $request)
    {
      try {
        $header = $request->header('Authorization');
        $token = str_replace("token ", "", $header);

        $signer = new Sha256();
        $publicKey = new Key(env('JWT_PUBLIC_KEY'));
        $token = (new Parser())->parse($token);
        if ( $token->verify($signer, $publicKey) ) {
          $data = $token->getClaims();

          Log::info(__METHOD__ . ' - meShop ', [
              'claims' => $data,
          ]);

          $configdoppler = ConfigDoppler::where('account', $data['unique_name'])->first();
          $user = User::where('id', $configdoppler->shop_id)->first();
          $request['shop'] = $user->name;
        } else {
          throw new \Exception("Invalid Parameters.", 400);
        }
      } catch (\Exception $e) {
        return response()->json(['status' => 'ERROR', "errorMessage" => "Invalid Parameters."], 400);
      }

      try {
        if(!isset($request['shop'])) {
          throw new \Exception("Invalid Parameters.", 400);
        }

        $params = $request->all();
        Log::info(__METHOD__ . ' - meShop ', [
            'params' => $params,
        ]);
        $service = app(DopplerService::class);
        $meShop = $service->getShopInfo($params);

        $data = [];
        array_push($data, $meShop);

        return $data;
      } catch (\Exception $e) {
        return response()->json(['status' => 'ERROR', "errorMessage" => $e->getMessage()], 400);
      }
    }

    /**
     * @param Request $request
     * @return MeShopResource
     */
    public function install(Request $request)
    {
      return view('install');
    }

    /**
     * @param Request $request
     * @return Application|Factory|View
     */
    public function login(Request $request)
    {
        $params = $request->all();
        $urlCallbackLang = 'login';
        list($current_lang, $secundary_lang) = $this->getLang($params);
        App::setlocale($current_lang);

        //shop name
        $service = app(DopplerService::class);
        $shopname = $service->getShopShortName($params);

        return view('login', compact('current_lang', 'secundary_lang', 'urlCallbackLang', 'shopname'));
    }

    /**
     * @param Request $request
     * @return Application|Factory|View
     */
    public function authenticate(Request $request)
    {
        $params = $request->all();
        Log::info(__METHOD__ . ' - sendLogin ', [
            'params' => $params['email'],
        ]);

        list($current_lang, $secundary_lang) = $this->getLang($params);
        App::setlocale($current_lang);

        //Recaptcha
        $validator = Validator::make(request()->all(), [
            'g-recaptcha-response' => 'recaptcha',
        ]);
        if($validator->fails()) {
            $errors = $validator->errors();
            return Redirect::back()->withInput($request->input())->withErrors(trans('login.error_generic'));
        }

        /** @var DopplerService $service */
        $service = app(DopplerService::class);
        try {
            $user = $service->authenticate($params);

            if(!isset($user['accountName'])) {

              $error_message = '';
              $error_code = isset($user['errorCode'])? $user['errorCode'] : '';
              switch($error_code) {
                case 2: $error_message = trans('login.error_2'); break;
                case 50: $error_message = trans('login.error_50'); break;
                case 51: $error_message = trans('login.error_51'); break;
                default: $error_message = trans('login.error_generic'); break;
              }
              return Redirect::back()->withInput($request->input())->withErrors($error_message);
            }
        } catch (\Exception $e) {
            return Redirect::back()->withInput($request->input())->withErrors(trans('login.error_generic'));
        }

        // register account in db //
        Log::info(__METHOD__ . ' - resultLogin ', [
            'params' => $user,
        ]);
        try {
            $service->setupApp(array("account"=> $user['accountName'], "api_key" => $user['apiKey']));
        } catch (\Exception $e) {
            return Redirect::back()->withInput($request->input())->withErrors(trans('login.error_generic'));
        }

        $subscribersList = [];
        $isSetup = true;
        $listConfigured = false;

        try {
          $subscribersList = $service->getSubscribersList();

          return view('setupStepThree', compact('subscribersList','isSetup', 'listConfigured'));
        } catch (\Exception $e) {
          return view('setupStepThree', compact('subscribersList','isSetup', 'listConfigured'))->withErrors($e->getMessage());
        }
    }

    /**
     * @param Request $request
     * @return Application|Factory|View
     */
    public function resetpassword(Request $request)
    {
        $params = $request->all();
        $urlCallbackLang = 'resetpassword';
        list($current_lang, $secundary_lang) = $this->getLang($params);
        App::setlocale($current_lang);

        //shop name
        $service = app(DopplerService::class);
        $shopname = $service->getShopShortName($params);

        return view('resetpassword', compact('current_lang', 'secundary_lang', 'urlCallbackLang', 'shopname'));
    }

    /**
     * @param Request $request
     * @return Application|Factory|View
     */
    public function sendresetpassword(Request $request)
    {
        $params = $request->all();
        $urlCallbackLang = 'resetpassword';
        list($current_lang, $secundary_lang) = $this->getLang($params);
        App::setlocale($current_lang);

        Log::info(__METHOD__ . ' - sendResetPassword ', [
            'params' => $params['email'],
        ]);

        //Recaptcha
        $validator = Validator::make(request()->all(), [
            'g-recaptcha-response' => 'recaptcha',
        ]);
        if($validator->fails()) {
            $errors = $validator->errors();
            return Redirect::back()->withInput($request->input())->withErrors(trans('login.error_generic'));
        }

        /** @var DopplerService $service */
        $service = app(DopplerService::class);
        try {
            $response = $service->resetpassword($params);

            if(isset($response['errorCode'])) {
              $error_message = '';
              $error_code = isset($response['errorCode'])? $response['errorCode'] : '';
              switch($error_code) {
                case 38: $error_message = trans('resetpassword.error_38'); break;
                default: $error_message = trans('resetpassword.error_generic'); break;
              }
              return Redirect::back()->withInput($request->input())->withErrors($error_message);
            }
        } catch (\Exception $e) {
            return Redirect::back()->withInput($request->input())->withErrors($e->getMessage());
        }

        // register account in db //
        Log::info(__METHOD__ . ' - resultSendResetPassword ', [
            'params' => $response,
        ]);

        //shop name
        $service = app(DopplerService::class);
        $shopname = $service->getShopShortName($params);
        $responseok = true;

        return view('resetpassword', compact('current_lang', 'secundary_lang', 'urlCallbackLang', 'shopname', 'responseok'));
    }

    /**
     * @param Request $request
     * @return Application|Factory|View
     */
    public function authenticatecode(Request $request, $email, $shop)
    {
        $params = $request->all();
        Log::info(__METHOD__ . ' - authenticateCode '.$email, [
            'params' => $params,
        ]);
        $has_error = false;
        $request['shop'] = $shop.'.myshopify.com';
        /** @var DopplerService $service */
        $service = app(DopplerService::class);

        try {
            $params['email'] = $email;
            $user = $service->authenticatecode($params);

            if(isset($user['errorCode'])) {
              list($current_lang, $secundary_lang) = $this->getLang($params);
              App::setlocale($current_lang);

              if(isset($user['errorCode'])) {
                $has_error = true;
                Log::info(__METHOD__ . ' - authenticateCodeError - '.$email , [
                    'params' => $user
                ]);
              }
            }
        } catch (\Exception $e) {
          $has_error = true;
          Log::info(__METHOD__ . ' - authenticateCodeError - '.$email , [
              'params' => $e->getMessage()
          ]);
        }

        if(!$has_error)  {
          // register account in db //
          Log::info(__METHOD__ . ' - resultAuthenticateCode ', [
              'params' => $user,
          ]);
          try {
              $service->setupApp(array("account"=> $user['accountName'], "api_key" => $user['apiKey']));
          } catch (\Exception $e) {
              //return Redirect::back()->withErrors($e->getMessage());
          }

          $url = $service->getShopifyAppUrl($shop);

          return Redirect::to($url);
        } else {
          return Redirect::to(env('DOPPLER_SITE'));
        }
    }

    /**
     * @param Request $request
     * @return Application|Factory|View
     */
    public function register(Request $request)
    {
        $params = $request->all();
        $urlCallbackLang = 'register';
        list($current_lang, $secundary_lang) = $this->getLang($params);
        App::setlocale($current_lang);

        //shop name
        $service = app(DopplerService::class);
        $shopname = $service->getShopShortName($params);

        return view('register', compact('current_lang', 'secundary_lang', 'urlCallbackLang', 'shopname'));
    }

    /**
     * @param Request $request
     * @return Application|Factory|View
     */
    public function signup(Request $request)
    {
        $params = $request->all();
        Log::info(__METHOD__ . ' - sendRegister ', [
            'params' => $params,
        ]);

        list($current_lang, $secundary_lang) = $this->getLang($params);
        App::setlocale($current_lang);

        //Recaptcha
        $validator = Validator::make(request()->all(), [
            'g-recaptcha-response' => 'recaptcha',
        ]);
        if($validator->fails()) {
            $errors = $validator->errors();
            return Redirect::back()->withInput($request->input())->withErrors(trans('register.error_generic'));
        }
        /** @var DopplerService $service */
        $service = app(DopplerService::class);

        $params['lang'] = $current_lang;
        $params['callBackUrl'] = $service->getCallBackUrl($params);

        try {
            $user = $service->signup($params);

            if(isset($user['errorCode'])) {
              $error_message = '';
              $error_code = isset($user['errorCode'])? $user['errorCode'] : '';
              switch($error_code) {
                case 4: $error_message = trans('register.error_4'); break;
                case 2: $error_message = trans('register.error_2'); break;
                case 37: $error_message = trans('register.error_37'); break;
                case 47: $error_message = trans('register.error_47'); break;
                case 48: $error_message = trans('register.error_48'); break;
                case 49: $error_message = trans('register.error_49'); break;
                default: $error_message = trans('register.error_generic'); break;
              }
              return Redirect::back()->withInput($request->input())->withErrors($error_message);
            }
        } catch (\Exception $e) {
            return Redirect::back()->withInput($request->input())->withErrors($e->getMessage());
        }

        //shop name
        $service = app(DopplerService::class);
        $shopname = $service->getShopShortName($params);
        $email = $params['email'];

        return view('confirmation', compact('current_lang', 'secundary_lang', 'shopname', 'email'));
    }

    /**
     * @param array $params
     * @return array
     */
    public function getLang(array $params)
    {
        $current_lang = 'es';
        $secundary_lang = 'en';
        if (isset($params['lang'])) {
            if ($params['lang'] == 'es') {
                $current_lang = $params['lang'];
                $secundary_lang = 'en';
            } else {
                $current_lang = $params['lang'];
                $secundary_lang = 'es';
            }
        }
        return array($current_lang, $secundary_lang);
    }

    /**
     * @param array $params
     * @return array
     */
    public function confirmation(Request $request)
    {
        $params = $request->all();
        //if(isset($params['email'])) {
          list($current_lang, $secundary_lang) = $this->getLang($params);
          App::setlocale($current_lang);

          //shop name
          $service = app(DopplerService::class);
          $shopname = $service->getShopShortName($params);

          $email = $params['email'];

          return view('confirmation', compact('current_lang', 'secundary_lang', 'shopname', 'email'));
        /*} else {
          return Redirect::route('register');
        }*/
    }

    /**
     * @param Request $request
     * @return Application|Factory|View
     */
    public function resendactivationemail(Request $request)
    {
        $params = $request->all();
        Log::info(__METHOD__ . ' - resendActivationEmail ', [
            'params' => $params,
        ]);
        /** @var DopplerService $service */
        list($current_lang, $secundary_lang) = $this->getLang($params);
        App::setlocale($current_lang);

        //shop name
        $service = app(DopplerService::class);
        $shopname = $service->getShopShortName($params);
        $email = $params['email'];

        $params['callBackUrl'] = $service->getCallBackUrl($params);

        $service = app(DopplerService::class);
        try {
            $user = $service->activationemail($params);

            if(isset($user['errorCode'])) {
              return view('confirmation', compact('current_lang', 'secundary_lang', 'shopname', 'email'))->withErrors(trans('register.error_generic'));
            }
        } catch (\Exception $e) {
            return view('confirmation', compact('current_lang', 'secundary_lang', 'shopname', 'email'))->withErrors($e->getMessage());
        }

        $resentemail = true;
        return view('confirmation', compact('current_lang', 'secundary_lang', 'shopname', 'resentemail', 'email'));
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function webhookCustomersData(Request $request)
    {
      $params = $request->all();
      Log::info(__METHOD__ . ' - webhookCustomersData ', [
          'params' => $params,
      ]);
      return response()->json(['success' => 'success'], 200);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function webhookCustomersRedact(Request $request)
    {
      $params = $request->all();
      Log::info(__METHOD__ . ' - webhookCustomersRedact ', [
          'params' => $params,
      ]);
      return response()->json(['success' => 'success'], 200);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function webhookShopRedact(Request $request)
    {
      $params = $request->all();
      Log::info(__METHOD__ . ' - webhookShopRedact ', [
          'params' => $params,
      ]);
      return response()->json(['success' => 'success'], 200);
    }
}
