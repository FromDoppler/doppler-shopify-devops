<?php

namespace App\Repositories;

interface ShopifyHTTRepositoryInterface
{
    public function getCustomer();

    public function getProducts();

    public function getWebhooks($params);

    public function setWebhooks($params);
}
