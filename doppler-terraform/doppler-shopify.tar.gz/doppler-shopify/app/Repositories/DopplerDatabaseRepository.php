<?php

namespace App\Repositories;

use App\Models\ConfigDoppler;
use App\Models\CurrentSubscriberList;
use App\Models\FieldMapping;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;

/**
 * Class AndreaniDatabaseRepository
 * @package App\Repositories\Andreani
 */
class DopplerDatabaseRepository implements DopplerDatabaseRepositoryInterface
{
    use ExternalTrait;

    /**
     * @var mixed
     */
    private $config;
    /**
     * @var array
     */
    private $shop_params;

    /**
     * AndreaniHTTRepository constructor.
     * @param Request $request
     * @throws \Exception
     */
    public function __construct(Request $request)
    {
        $this->config = Config::get('external')['doppler'];
        /** @var User $user */
        $user = app(User::class);
        $this->shop_params = $user->getShopParameters($request->all());
    }

    /**
     * @param $params
     * @return mixed
     * @throws \Exception
     */
    public function setupApp($params)
    {
        try {
            /** @var ConfigDoppler $config */
            $setupDoppler = ConfigDoppler::create(
                array_merge($params, [
                    'step' => 'setupStepThree',
                    'shop_id' => $this->shop_params['id'],
                    'sync_process_in_progress' => 'unlock',
            ]));
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }

        return $setupDoppler;
    }

    /**
     * @param $params
     * @return mixed
     * @throws \Exception
     */
    public function setCurrentSubscriberList($params)
    {
        try {
            /** @var CurrentSubscriberList $currentList */
            $currentList = CurrentSubscriberList::where('shop_id', $this->shop_params['id'])->get();
            if ($currentList->isEmpty()) {
                $params['shop_id'] = $this->shop_params['id'];
                $currentList = CurrentSubscriberList::create($params);
            } else {
                $currentList = $currentList->first();
                $currentList->list_id = $params['list_id'];
                $currentList->list_name = $params['list_name'];
                $currentList = $currentList->save();
            }
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }

        return $currentList;
    }

    /**
     * @param $params
     * @return mixed
     * @throws \Exception
     */
    public function disassociateCurrentSubscriberList($params)
    {
        $disassociate_subscribers = true;
        try {
            /** @var CurrentSubscriberList $currentList */
            $currentList = CurrentSubscriberList::where('shop_id', $this->shop_params['id'])->get();
            $disassociate_subscribers = true;
            if (!$currentList->isEmpty()) {
                $currentList = $currentList->first();
                if($currentList->list_id == $params['list_id']) {
                  $disassociate_subscribers = false;
                }
            }
        } catch (\Exception $e) {
            $disassociate_subscribers = false;
        }
        return $disassociate_subscribers;
    }

    /**
     * @param $fields
     * @return mixed
     * @throws \Exception
     */
    public function setFiedlMapping($fields)
    {
        try {
            /** @var FieldMapping $config */
            $fieldMappings = FieldMapping::where('shop_id', $this->shop_params['id'])->get();
            if ($fieldMappings->isEmpty()) {
                $fieldMappings = FieldMapping::insert([
                    'field_mapping' => json_encode($fields),
                    'shop_id' => $this->shop_params['id'],
                ]);
            } else {
                $fieldMappings = $fieldMappings->first();
                $fieldMappings->field_mapping = json_encode($fields);
                $fieldMappings = $fieldMappings->save();
            }
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }

        return $fieldMappings;
    }

    /**
     * @return mixed
     * @throws \Exception
     */
    public function getFiedlMapping()
    {
        try {
            /** @var FieldMapping $config */
            $fieldMappings = FieldMapping::where('shop_id', $this->shop_params['id'])->get();
            if ($fieldMappings->isEmpty()) {
                $integrationConfig = Config::get('external')['integration'];
                $field_mapping = $integrationConfig['field_mapping'];
            } else {
                $field_mapping = $fieldMappings->first();
                $field_mapping = json_decode($field_mapping->field_mapping, true);
            }
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }

        return $field_mapping;
    }

    /**
     * @return mixed
     * @throws \Exception
     */
    public function uninstallApp($params)
    {
        try {
            $user = User::where('name', $params['domain'])->first();
            if (!empty($user)) {
                $shopId = $user->id;
                $user->forceDelete();
                FieldMapping::where('shop_id', $shopId)->delete();
                CurrentSubscriberList::where('shop_id', $shopId)->delete();
                ConfigDoppler::where('shop_id', $shopId)->delete();
            } else {
              throw new \Exception('Shop not exists.');
            }
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }

        return true;
    }

    /**
     * @param null $shopId
     * @return mixed
     * @throws \Exception
     */
    public function getCurrentSubscriberList($shopId = null)
    {
        $shopId = !empty($shopId) ? $shopId : $this->shop_params['id'];
        try {
            /** @var CurrentSubscriberList $currentList */
            $currentList = CurrentSubscriberList::where('shop_id', $shopId)->get();
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }

        return $currentList;
    }

    /**
     * @param null $shopId
     * @return mixed
     * @throws \Exception
     */
    public function getConfigDoppler($shopId = null)
    {
        $shopId = !empty($shopId) ? $shopId : $this->shop_params['id'];
        try {
            /** @var ConfigDoppler $configDoppler */
            $configDoppler = ConfigDoppler::where('shop_id', $shopId)->get();
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }

        return $configDoppler;
    }

    /**
     * @param $process
     * @return mixed
     * @throws \Exception
     */
    public function processSync($process)
    {
        try {
            /** @var ConfigDoppler $configDoppler */
            $configDoppler = ConfigDoppler::where('shop_id', $this->shop_params['id'])->get();
            $configDoppler = $configDoppler->first();
            $configDoppler->sync_process_in_progress = $process;
            $configDoppler->save();
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }
        return $configDoppler;
    }
}
