<?php
namespace App\Repositories;

use GuzzleHttp\Utils;
use Illuminate\Support\Facades\Auth;

/**
 * Class ExternalTrait
 */
trait ExternalTrait
{
    /**
     * @param $access_token
     * @return string
     */
    public function getShopifyUri($shop_params)
    {
        return $this->config['options']['protocol'].$this->config['options']['api_key'].':'.$shop_params['password'].'@' . $shop_params['shop_name'];
    }

    /**
     * @param string $action
     * @param array $params
     * @return array
     * @throws \Exception
     */
    private function buildCallExternalRequest(string $action, array $params)
    {
        $data = [];
        $method = 'buildRequest' . ucfirst($action);
        if (!method_exists($this, $method)) {
            throw new \Exception('the param builder not exist');
        }

        return $this->$method($params);
    }

    /**
     * @param $params
     * @return array
     */
    private function buildRequestGetOrder($params)
    {
        return [
            'uri' => $this->config['options']['protocol'] . $this->config['options']['base_uri'] . str_replace('@id_order', $params['id'], $this->config['get_order']['path']),
            'method' => $this->config['get_order']['method'],
            'options' => [
                'headers' => [
                    'X-Shopify-Access-Token' => $this->access_token
                ]
            ],
        ];
    }

    /**
     * @param $params
     * @return array
     */
    private function buildRequestGetSubscribersList($params)
    {
        return [
            'uri' => $this->config['options']['base_uri'] . str_replace('@account', $params['account'], $this->config['get_subscribers_list']['path']),
            'method' => $this->config['get_subscribers_list']['method'],
            'options' => [
                'headers' => [
                    'Authorization' => 'token '.$params['api_key']
                ]
            ],
        ];
    }

    /**
     * @param $params
     * @return array
     */
    private function buildRequestGetSubscribersListById($params)
    {
        return [
            'uri' => $this->config['options']['base_uri'] . str_replace('@account', $params['account'], $this->config['get_subscribers_list']['path']).'/'.$params['id'],
            'method' => $this->config['get_subscribers_list']['method'],
            'options' => [
                'headers' => [
                    'Authorization' => 'token '.$params['api_key']
                ]
            ],
        ];
    }

    /**
     * @param $params
     * @return array
     */
    private function buildRequestAuthenticate($params)
    {
        return [
            'uri' => $this->config['options']['base_uri'] . $this->config['login']['path'],
            'method' => $this->config['login']['method'],
            'options' => [
                'headers' => [
                    'Authorization' => 'token '.env('DOPPLER_TOKEN')
                ],
                'body' => json_encode([
                    'grant_type' => 'password',
                    'username' => $params['email'],
                    'password' => $params['password'],
                ])
            ],
        ];
    }

    /**
     * @param $params
     * @return array
     */
    private function buildRequestResetpassword($params)
    {
        return [
            'uri' => $this->config['options']['base_uri'] . $this->config['resetpassword']['path'] . '?email=' . urlencode($params['email']),
            'method' => $this->config['resetpassword']['method'],
            'options' => [
                'headers' => [
                    'Authorization' => 'token '.env('DOPPLER_TOKEN')
                ]
            ],
        ];
    }

    /**
     * @param $params
     * @return array
     */
    private function buildRequestAuthenticatecode($params)
    {
        return [
            'uri' => $this->config['options']['base_uri'] . $this->config['login']['path'],
            'method' => $this->config['login']['method'],
            'options' => [
                'headers' => [
                    'Authorization' => 'token '.env('DOPPLER_TOKEN')
                ],
                'body' => json_encode([
                    'grant_type' => 'authorization_code',
                    'username' => $params['email'],
                    'code' => $params['code'],
                ])
            ],
        ];
    }

    /**
     * @param $params
     * @return array
     */
    private function buildRequestSignup($params)
    {
        return [
            'uri' => $this->config['options']['base_uri'] . $this->config['signup']['path'],
            'method' => $this->config['signup']['method'],
            'options' => [
                'headers' => [
                    'Authorization' => 'token '.env('DOPPLER_TOKEN')
                ],
                'body' => json_encode([
                    'email' => $params['email'],
                    'firstName' => $params['firstName'],
                    'lastName' => $params['lastName'],
                    'password' => $params['password'],
                    'phone' => $params['phone'],
                    'origin' => "Shopify",
                    'language' => $params['lang'],
                    'termsAndConditionsActive' => true,
                    'promotionsEnabled' => true,
                    'callBackUrl' => $params['callBackUrl']
                ])
            ],
        ];
    }

    /**
     * @param $params
     * @return array
     */
    private function buildRequestActivationemail($params)
    {
        return [
            'uri' => $this->config['options']['base_uri'] . $this->config['activationemail']['path'] .'?email=' . urlencode($params['email']) . '&callBackUrl='.$params['callBackUrl'],
            'method' => $this->config['activationemail']['method'],
            'options' => [
                'headers' => [
                    'Authorization' => 'token '.env('DOPPLER_TOKEN')
                ],
                'body' => json_encode([
                    'email' => urlencode($params['email']),
                    'callBackUrl' => $params['callBackUrl']
                ])
            ],
        ];
    }

    /**
     * @param $params
     * @return array
     */
    private function buildRequestGetAccount($params)
    {
        return [
            'uri' => $this->config['options']['base_uri'] . str_replace('@account', $params['account'], $this->config['get_account']['path']),
            'method' => $this->config['get_account']['method'],
            'options' => [
                'headers' => [
                    'Authorization' => 'token '.$params['api_key']
                ]
            ],
        ];
    }

    /**
     * @param $params
     * @return array
     */
    private function buildRequestCreateSubscribersList($params)
    {
        return [
            'uri' => $this->config['options']['base_uri'] . str_replace('@account', $params['account'], $this->config['create_subscribers_list']['path']),
            'method' => $this->config['create_subscribers_list']['method'],
            'options' => [
                'headers' => [
                    'Authorization' => 'token '.$params['api_key']
                ],
                'body' => json_encode([
                    'name' => $params['subscriptionList'],
                ])
            ],
        ];
    }

    /**
     * @param $params
     * @return array
     */
    private function buildRequestGetCustomFields($params)
    {
        return [
            'uri' => $this->config['options']['base_uri'] . str_replace('@account', $params['account'], $this->config['get_fields_account']['path']),
            'method' => $this->config['get_fields_account']['method'],
            'options' => [
                'headers' => [
                    'Authorization' => 'token '.$params['api_key']
                ]
            ],
        ];
    }

    /**
     * @param $params
     * @return array
     */
    private function buildRequestSyncDopplerData($params)
    {
        return [
            'uri' => $this->config['options']['base_uri'] . str_replace('@account', $params['account'],str_replace('@list_id', $params['list_id'], $this->config['import_subscribers']['path'])),
            'method' => $this->config['import_subscribers']['method'],
            'options' => [
                'headers' => [
                    'Authorization' => 'token '.$params['api_key'],
                    'X-Doppler-Subscriber-Origin' => 'Shopify',
                ],
                'body' => json_encode($params['sync_data'])
            ],
        ];
    }

    /**
     * @param $params
     * @return array
     */
    private function buildRequestDeleteListSubscribers($params)
    {
        return [
            'uri' => $this->config['options']['base_uri'] . str_replace('@account', $params['account'],str_replace('@list_id', $params['list_id'], $this->config['delete_subscribers_list']['path'])),
            'method' => $this->config['delete_subscribers_list']['method'],
            'options' => [
                'headers' => [
                    'Authorization' => 'token '.$params['api_key'],
                    'X-Doppler-Subscriber-Origin' => 'Shopify',
                ]
            ],
        ];
    }

    /**
     * @param $params
     * @return array
     */
    private function buildRequestSetIntegrations($params)
    {
        return [
            'uri' => $this->config['options']['base_uri'] . str_replace('@account', $params['account'], $this->config['set_integration']['path']),            'method' => $this->config['set_integration']['method'],
            'options' => [
                'headers' => [
                    'Authorization' => 'token '.$params['api_key']
                ],
                'body' => json_encode($params['integration_params'])
            ],
        ];
    }

    /**
     * @param $params
     * @return array
     */
    private function buildRequestDeleteIntegrations($params)
    {
        return [
            'uri' => $this->config['options']['base_uri'] . str_replace('@account', $params['account'], $this->config['delete_integration']['path']),
            'method' => $this->config['delete_integration']['method'],
            'options' => [
                'headers' => [
                    'Authorization' => 'token '.$params['api_key']
                ]
            ],
        ];
    }

    /**
     * @param $params
     * @return array
     */
    private function buildRequestSetWebhooks($params)
    {
        $shopParameters = $this->getShopParameters();
        $uri = $this->config['options']['protocol'] . $shopParameters['shop_name'];
        return [
            'uri' => $uri . $this->config['set_webhook']['path'],
            'method' => $this->config['set_webhook']['method'],
            'options' => [
                'form_params' => [
                    'webhook' =>  [
                        'topic' => $params['topic'],
                        'address' => $params['path'] . $shopParameters['shop_name'],
                        'format' => 'json',
                    ]
                ],
                'headers' => [
                    'X-Shopify-Access-Token' => $shopParameters['password']
                ]
            ],
        ];
    }
}
