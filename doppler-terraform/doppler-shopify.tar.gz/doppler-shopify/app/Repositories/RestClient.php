<?php

namespace App\Repositories;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Psr7\Response;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Log;

/**
 * Class RestClient
 * @package App\Repositories
 */
class RestClient
{
    /** @var Client */
    private $client;

    /**
     * @var
     */
    private $header_response;

    /**
     * AndreaniHTTRepository constructor.
     */
    public function __construct()
    {
        $this->client = app(Client::class);
    }

    /**
     * @param $method
     * @param $uri
     * @param $options
     * @return Collection
     * @throws GuzzleException
     */
    public function call($method, $uri, $options)
    {
        try {
            $init = microtime(true);
            $this->logInfo(['request' => ['method' => $method, 'uri' => $uri, 'options' => $options]], __METHOD__.__LINE__);
            $response = $this->client->request($method, $uri, $options);
            $this->setHeaderResponse($response->getHeaders());
        } catch (ClientException $e) {
            $this->logError($e->getMessage(), __METHOD__ . __LINE__);
            $error = json_decode($e->getResponse()->getBody()->getContents(), true);
            if (isset($error['status']) && ($error['status'] == '400' || $error['status'] == '401' || $error['status'] == '404' || $error['status'] == '429') && isset($error['title'])) {
                return collect($error);
            }
            if (isset($error['errors']) && $error['errors'] == 'Not Found' || isset($error['status']) && $error['status'] == 403) {
                return collect($error);
            }
            throw new \Exception($e->getMessage());
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }
        $end = microtime(true);
        $response = $this->getJsonDecodeFromResponse($response);
        $this->logInfo(['response' => $response, 'time' => ($end - $init)], __METHOD__ . __LINE__);

        return collect($response);
    }

    /**
     * @param Response $response
     * @return mixed
     */
    private function getJsonDecodeFromResponse(Response $response)
    {
        return json_decode($response->getBody()->getContents());
    }

    /**
     * @param $info
     * @param $method
     */
    private function logInfo($info, $method)
    {
        Log::info($method . ' - rest_client ', [
            $info,
        ]);
    }

    /**
     * @param $message
     * @param $method
     */
    private function logError($message, $method)
    {
        Log::error($method . ' - rest_client_error ', [
            'error' => $message,
        ]);
    }

    /**
     * @return mixed
     */
    public function getHeaderResponse()
    {
        return $this->header_response;
    }

    /**
     * @param mixed $header_response
     */
    public function setHeaderResponse($header_response)
    {
        $this->header_response = $header_response;
    }
}
