<?php

namespace App\Repositories;

interface DopplerDatabaseRepositoryInterface
{
    public function setupApp($params);

    public function setCurrentSubscriberList($params);

    public function setFiedlMapping($params);

    public function getFiedlMapping();

    public function uninstallApp($params);

    public function getCurrentSubscriberList();

    public function getConfigDoppler();

    public function processSync($process);
}
