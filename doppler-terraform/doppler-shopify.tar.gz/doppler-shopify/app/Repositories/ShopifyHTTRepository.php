<?php

namespace App\Repositories;

use App\Models\User;
use GuzzleHttp\Exception\GuzzleException;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;

/**
 * Class OrderHTTRepositoryInterface
 * @package App\Repositories
 */
class ShopifyHTTRepository implements ShopifyHTTRepositoryInterface
{
    use ExternalTrait;

    /**
     * @var RestClient
     */
    private $client;
    /**
     * @var mixed
     */
    private $config;
    /**
     * @var
     */
    private $access_token;
    /**
     * @var
     */
    private $shop_params;

    /**
     * OrderHTTRepository constructor.
     * @param Request $request
     * @throws \Exception
     */
    public function __construct(Request $request)
    {
        $this->client = app(RestClient::class);
        $this->config = Config::get('external')['shopify'];
        /** @var User $user */
        $user = app(User::class);
        $this->shop_params = $user->getShopParameters($request->all());
    }

    public function getShopParameters()
    {
        return $this->shop_params;
    }

    /**
     * @return Collection
     * @throws GuzzleException
     */
    public function getCustomer()
    {
        $uri = $this->getShopifyUri($this->shop_params);
        return $this->client->call(
            $this->config['get_customer']['method'],
            $uri . $this->config['get_customer']['path'],
            []
        );
    }

    /**
     * @return Collection
     * @throws GuzzleException
     */
    public function getProducts()
    {
        $uri = $this->getShopifyUri($this->shop_params);
        return $this->client->call(
            $this->config['get_products']['method'],
            $uri . $this->config['get_products']['path'],
            []
        );
    }

    /**
     * @param $params
     * @return Collection
     * @throws GuzzleException
     */
    public function getWebhooks($params)
    {
        $uri = $this->getShopifyUri($this->shop_params);
        return $this->client->call(
            $this->config['get_webhooks']['method'],
            $uri . $this->config['get_webhooks']['path'],
            []
        );
    }

    /**
     * @param $params
     * @return Collection
     * @throws GuzzleException
     */
    public function setWebhooks($params)
    {
        $data = $this->buildCallExternalRequest(__FUNCTION__, $params);
        return $this->client->call(
            $data['method'],
            $data['uri'],
            $data['options']
        );
    }
}
