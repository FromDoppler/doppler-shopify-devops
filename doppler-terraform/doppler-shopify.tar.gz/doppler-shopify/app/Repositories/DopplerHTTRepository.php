<?php

namespace App\Repositories;

use GuzzleHttp\Exception\GuzzleException;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Config;

/**
 * Class DopplerHTTRepository
 * @package App\Repositories
 */
class DopplerHTTRepository implements DopplerHTTRepositoryInterface
{
    use ExternalTrait;

    /** @var RestClient */
    private $client;
    /**
     * @var mixed
     */
    private $config;

    /**
     * AndreaniHTTRepository constructor.
     */
    public function __construct()
    {
        $this->client = app(RestClient::class);
        $this->config = Config::get('external')['doppler'];
    }

    /**
     * @param $params
     * @return Collection|mixed
     * @throws GuzzleException
     * @throws \Exception
     */
    public function getSubscribersList($params)
    {
        $data = $this->buildCallExternalRequest(__FUNCTION__, $params);
        $subscribersList = $this->client->call($data['method'], $data['uri'], $data['options']);
        return $subscribersList->get('items');
    }

    /**
     * @param $params
     * @return Collection|mixed
     * @throws GuzzleException
     * @throws \Exception
     */
    public function getSubscribersListById($params)
    {
      try {
        $data = $this->buildCallExternalRequest(__FUNCTION__, $params);
        $subscribersList = $this->client->call($data['method'], $data['uri'], $data['options']);
        return $subscribersList->get('currentStatus') != 'deleted' ? $subscribersList->get('name') : null;
      } catch (\Exception $e) {
        return null;
      }
    }

    /**
     * @param $params
     * @return Collection|mixed
     * @throws GuzzleException
     * @throws \Exception
     */
    public function getAccount($params)
    {
        $data = $this->buildCallExternalRequest(__FUNCTION__, $params);
        return $this->client->call($data['method'], $data['uri'], $data['options']);
    }

    /**
     * @param $params
     * @return Collection|mixed
     * @throws GuzzleException
     * @throws \Exception
     */
    public function authenticate($params)
    {
        $data = $this->buildCallExternalRequest(__FUNCTION__, $params);
        return $this->client->call($data['method'], $data['uri'], $data['options']);
    }

    /**
     * @param $params
     * @return Collection|mixed
     * @throws GuzzleException
     * @throws \Exception
     */
    public function resetpassword($params)
    {
        $data = $this->buildCallExternalRequest(__FUNCTION__, $params);
        return $this->client->call($data['method'], $data['uri'], $data['options']);
    }

    /**
     * @param $params
     * @return Collection|mixed
     * @throws GuzzleException
     * @throws \Exception
     */
    public function authenticatecode($params)
    {
        $data = $this->buildCallExternalRequest(__FUNCTION__, $params);
        return $this->client->call($data['method'], $data['uri'], $data['options']);
    }

    /**
     * @param $params
     * @return Collection|mixed
     * @throws GuzzleException
     * @throws \Exception
     */
    public function signup($params)
    {
        $data = $this->buildCallExternalRequest(__FUNCTION__, $params);
        return $this->client->call($data['method'], $data['uri'], $data['options']);
    }

    /**
     * @param $params
     * @return Collection|mixed
     * @throws GuzzleException
     * @throws \Exception
     */
    public function activationemail($params)
    {
        $data = $this->buildCallExternalRequest(__FUNCTION__, $params);
        return $this->client->call($data['method'], $data['uri'], $data['options']);
    }

    /**
     * @param $params
     * @return Collection|mixed
     * @throws GuzzleException
     * @throws \Exception
     */
    public function createSubscribersList($params)
    {
        $data = $this->buildCallExternalRequest(__FUNCTION__, $params);
        return $this->client->call($data['method'], $data['uri'], $data['options']);
    }

    /**
     * @param $params
     * @return Collection|mixed
     * @throws GuzzleException
     * @throws \Exception
     */
    public function getCustomFields($params)
    {
        $data = $this->buildCallExternalRequest(__FUNCTION__, $params);
        return $this->client->call($data['method'], $data['uri'], $data['options']);
    }

    /**
     * @param $params
     * @return Collection|mixed
     * @throws GuzzleException
     * @throws \Exception
     */
    public function syncDopplerData($params)
    {
        $data = $this->buildCallExternalRequest(__FUNCTION__, $params);
        return $this->client->call($data['method'], $data['uri'], $data['options']);
    }

    /**
     * @param $params
     * @return Collection|mixed
     * @throws GuzzleException
     * @throws \Exception
     */
    public function deleteListSubscribers($params)
    {
        $data = $this->buildCallExternalRequest(__FUNCTION__, $params);
        return $this->client->call($data['method'], $data['uri'], $data['options']);
    }

    /**
     * @param $params
     * @return Collection|mixed
     * @throws GuzzleException
     * @throws \Exception
     */
    public function setIntegrations($params)
    {
        $data = $this->buildCallExternalRequest(__FUNCTION__, $params);
        return $this->client->call($data['method'], $data['uri'], $data['options']);
    }

    /**
     * @param $params
     * @return Collection|mixed
     * @throws GuzzleException
     * @throws \Exception
     */
    public function deleteIntegrations($params)
    {
        $data = $this->buildCallExternalRequest(__FUNCTION__, $params);
        return $this->client->call($data['method'], $data['uri'], $data['options']);
    }
}
