<?php

namespace App\Repositories;

interface DopplerHTTRepositoryInterface
{
    public function getSubscribersList($params);

    public function getAccount($params);

    public function authenticate($params);

    public function createSubscribersList($params);

    public function getCustomFields($params);

    public function syncDopplerData($params);

    public function setIntegrations($array);

    public function deleteIntegrations($array);
}
