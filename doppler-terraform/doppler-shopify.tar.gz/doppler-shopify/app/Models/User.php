<?php

namespace App\Models;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Osiset\ShopifyApp\Contracts\ShopModel as IShopModel;
use Osiset\ShopifyApp\Exceptions\MissingShopDomainException;
use Osiset\ShopifyApp\Traits\ShopModel;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable implements IShopModel
{
    use HasFactory, Notifiable, ShopModel;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'email',
        'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    /**
     * @param $params
     * @return mixed
     */
    public function getShopName($params)
    {
        $shop = Auth::user();
        if (!empty($shop)) {
            $shopName = $shop->getDomain()->toNative();
        } else {
            $shopName = isset($params['shop']) ? $params['shop'] : null;
        }
        if (empty($shopName)) {
            throw new MissingShopDomainException();
        }
        return $shopName;
    }

    /**
     * @param $params
     * @return mixed
     */
    public function getShopShortName($params)
    {
        $shopName = $this->getShopName($params);
        return str_replace('.myshopify.com', '', $shopName);
    }

    /**
     * @param $params
     * @return array
     * @throws \Exception
     */
    public function getShopParameters($params)
    {
        $shopName = $this->getShopName($params);
        $user = $this->where('name', $shopName)->get();
        if ($user->isEmpty()) {
            throw new \Exception('SHOP_NOT_CONFIGURED');
        }
        $user = $user->first();
        return [
            'id' => $user->id,
            'shop_name' => $user->name,
            'shop_email' => $user->email,
            'password' => $user->password,
        ];
    }

}
