<?php

namespace App\Services;

use App\Repositories\ShopifyHTTRepositoryInterface;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Config;

/**
 * Class OrderService
 * @package App\Services
 */
class ShopifyService
{
    /**
     * @var ShopifyHTTRepositoryInterface
     */
    private $repository;

    /**
     * OrderService constructor.
     * @param ShopifyHTTRepositoryInterface $repository
     */
    public function __construct(ShopifyHTTRepositoryInterface $repository)
    {
        $this->repository = $repository;
    }

    /**
     * @return Collection
     */
    public function getCustomer()
    {
        $customer = $this->repository->getCustomer();
        return collect($customer->get('customers'));
    }

    /**
     * @param $fields
     * @param $customerHook
     * @return array
     */
    public function synchronizeCustomersData($fields, $customerHook = [])
    {
        $customers = $this->repository->getCustomer();
        $customers = json_decode(json_encode($customers->get('customers')), true);
        if (!empty($customerHook)) {
            $push = true;
            foreach ($customers as $key => $customer) {
                if ($customer['id'] == $customerHook['id']) {
                    $customers[$key] = $customerHook;
                    $push = false;
                }
            }
            if ($push){
                array_push($customers, $customerHook);
            }
        }
        return $this->buildDataSync($customers, $fields);
    }

    /**
     * @param $customers
     * @param $fields
     * @return array
     */
    private function buildDataSync($customers, $fields)
    {
        $items = [];
        foreach ($fields as $field) {
            $fieldsDoppler[] = $field['doppler_field'];
        }
        foreach ($customers as $customer) {
            if (!empty($customer['default_address'])) {
              /*foreach ($customer['default_address'] as $k => $v) {
                $customer["default_address".$k] = $v;
              }*/
                $customer["default_address.id"] = $customer['default_address']["id"];
            		$customer["default_address.customer_id"] = $customer['default_address']["customer_id"];
            		$customer["default_address.first_name"] = $customer['default_address']["first_name"];
            		$customer["default_address.last_name"] = $customer['default_address']["last_name"];
            		$customer["default_address.company"] = $customer['default_address']["company"];
            		$customer["default_address.address1"] = $customer['default_address']["address1"];
            		$customer["default_address.address2"] = $customer['default_address']["address2"];
            		$customer["default_address.city"] = $customer['default_address']["city"];
            		$customer["default_address.province"] = $customer['default_address']["province"];
            		$customer["default_address.country"] = $customer['default_address']["country"];
            		$customer["default_address.zip"] = $customer['default_address']["zip"];
            		$customer["default_address.phone"] = $customer['default_address']["phone"];
            		$customer["default_address.name"] = $customer['default_address']["name"];
            		$customer["default_address.province_code"] = $customer['default_address']["province_code"];
            		$customer["default_address.country_code"] = $customer['default_address']["country_code"];
            		$customer["default_address.country_name"] = $customer['default_address']["country_name"];
                unset($customer['default_address']);
            }
            $fieldSend = [];
            foreach ($fields as $field) {
                $path = $field['path'];
                $fieldSend[] = [
                    "name" => $field['doppler_field'], "value" => isset($customer[$path]) ? $customer[$path] : ''
                ];
            }
            $items[] = [
                'email' => $customer['email'],
                'fields' => $fieldSend
            ];
        }
        return [
            "fields" => $fieldsDoppler,
            "items" =>$items
        ];
    }

    /**
     * @param $params
     * @return Collection
     */
    public function getProducts($params)
    {
        /** @var Collection $products */
        $products = new Collection($this->repository->getProducts()->get('products'));
        if (!empty($params['id'])) {
            $products = $products->whereIn('id',$params['id']);
        }
        return $products;
    }

    /**
     * @param array $params
     * @return mixed
     */
    public function getWebhooks(array $params)
    {
        return $this->repository->getWebhooks($params);
    }

    /**
     * @param array $params
     * @return mixed
     */
    public function setWebhooks(array $params)
    {
        return $this->repository->setWebhooks($params);
    }
}
