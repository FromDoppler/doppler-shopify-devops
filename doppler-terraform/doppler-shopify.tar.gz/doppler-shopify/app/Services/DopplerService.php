<?php

namespace App\Services;

use App\Models\ConfigDoppler;
use App\Models\CurrentSubscriberList;
use App\Models\User;
use App\Repositories\DopplerDatabaseRepositoryInterface;
use App\Repositories\DopplerHTTRepositoryInterface;
use Carbon\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Config;
use Mockery\Exception;

/**
 * Class DopplerService
 * @package App\Services
 */
class DopplerService
{
    /**
     * @var DopplerDatabaseRepositoryInterface
     */
    private $repositoryDatabase;
    /**
     * @var DopplerHTTRepositoryInterface
     */
    private $repository;

    /**
     * AndreaniShippingService constructor.
     * @param DopplerHTTRepositoryInterface $repository
     * @param DopplerDatabaseRepositoryInterface $repositoryDatabase
     */
    public function __construct(DopplerHTTRepositoryInterface $repository, DopplerDatabaseRepositoryInterface $repositoryDatabase)
    {
        $this->repository = $repository;
        $this->repositoryDatabase = $repositoryDatabase;
    }

    /**
     * @return bool
     */
    public function isConfigured()
    {
        $isConfigured = false;
        /** @var ConfigDoppler $dopplerSetup */
        $dopplerSetup = $this->getConfigDoppler();
        if ($dopplerSetup->isNotEmpty()) {
            $step = $dopplerSetup->toArray()[0]['step'];
            if ($step == 'finish') {
                $isConfigured = true;
            }
        }
        return $isConfigured;
    }

    /**
     * @return string
     */
    public function getStepSetup()
    {
        $step = null;
        /** @var ConfigDoppler $dopplerSetup */
        $dopplerSetup = $this->getConfigDoppler();
        if ($dopplerSetup->isNotEmpty()) {
            $step = $dopplerSetup->toArray()[0]['step'];
        }
        return $step;
    }

    /**
     * @return array
     */
    public function getDopplerConfig()
    {
        $dopplerConfig = $this->getConfigDoppler()->first()->toArray();
        $currentList = $this->getCurrentSubscriberList()->first()->toArray();
        $last_sync = Carbon::parse($dopplerConfig['last_sync'])->format('d/m/Y H:i:s');
        return [
            'last_sync' => $last_sync,
            'account' => $dopplerConfig['account'],
            'list_name' => $currentList['list_name'],
        ];
    }

    /**
     * @param $params
     * @return Collection
     */
    public function getSubscribersList()
    {
        /** @var ConfigDoppler $dopplerConfig */
        $dopplerConfig = $this->getConfigDoppler()->first();
        return $this->repository->getSubscribersList([
            'account' => $dopplerConfig->getAttribute('account'),
            'api_key' => $dopplerConfig->getAttribute('api_key'),
        ]);
    }

    /**
     * @param $params
     * @return Collection
     */
    public function setupApp($params)
    {
        $account = $this->getAccount($params);
        if ($account->isEmpty()) {
            throw new Exception('Bad credentials');
        }
        $this->repositoryDatabase->setupApp($params);
        $this->setAllWebhook();
        return $this->setIntegrations();
    }

    /**
     * @param $params
     * @return Collection
     */
    public function getAccount($params)
    {
        return $this->repository->getAccount($params);
    }

    /**
     * @param $params
     * @return Collection
     */
    public function authenticate($params)
    {
        /** @var ConfigDoppler $dopplerConfig */
        return $this->repository->authenticate([
            'email' => $params['email'],
            'password' => $params['password'],
        ]);
    }

    /**
     * @param $params
     * @return Collection
     */
    public function resetpassword($params)
    {
        /** @var ConfigDoppler $dopplerConfig */
        return $this->repository->resetpassword([
            'email' => $params['email'],
        ]);
    }

    /**
     * @param $params
     * @return Collection
     */
    public function authenticatecode($params)
    {
        /** @var ConfigDoppler $dopplerConfig */
        return $this->repository->authenticatecode([
            'email' => $params['email'],
            'code' => $params['code'],
        ]);
    }

    /**
     * @param $params
     * @return Collection
     */
    public function signup($params)
    {
        /** @var ConfigDoppler $dopplerConfig */
        return $this->repository->signup([
            'email' => $params['email'],//
            'password' => $params['password'],//
            'firstName' => $params['firstname'],//
            'lastName' => $params['lastname'],//
            'phone' => $params['phone'],//
            'lang' => $params['lang'],
            'terms' => $params['accept_privacy_policies'] == '1',
            'promotions' => isset($params['accept_promotions']) ? $params['accept_promotions'] == '1' : false,
            'callBackUrl' => $params['callBackUrl']
        ]);
    }

    /**
     * @param $params
     * @return Collection
     */
    public function activationemail($params)
    {
        /** @var ConfigDoppler $dopplerConfig */
        return $this->repository->activationemail([
            'email' => $params['email'],
            'callBackUrl' => $params['callBackUrl']
        ]);
    }

    /**
     * @param $params
     * @return Collection
     */
    public function createSubscribersList($params)
    {
        /** @var ConfigDoppler $dopplerConfig */
        $dopplerConfig = $this->getConfigDoppler()->first();
        return $this->repository->createSubscribersList([
            'subscriptionList' => $params['subscriptionList'],
            'account' => $dopplerConfig->getAttribute('account'),
            'api_key' => $dopplerConfig->getAttribute('api_key'),
        ]);
    }

    /**
     * @param $params
     * @return Collection
     */
    public function setCurrentSubscriberList($params)
    {
        /** @var ConfigDoppler $dopplerConfig */
        $dopplerConfig = $this->getConfigDoppler()->first();
        $dopplerConfig->update(['step' => 'setupStepFour']);

        $disassociate = $this->repositoryDatabase->disassociateCurrentSubscriberList($params);

        if($disassociate) {
          /** @var ConfigDoppler $dopplerConfig */
          /*$dopplerConfig = $this->getConfigDoppler()->first();    PREGUNTAR POR METODO QUE BORRE LOS SUSCRIPTORES
          $this->repository->deleteListSubscribers([
              'list_id' => $params['list_id'],
              'account' => $dopplerConfig->getAttribute('account'),
              'api_key' => $dopplerConfig->getAttribute('api_key'),
          ]);*/
        }

        return $this->repositoryDatabase->setCurrentSubscriberList($params);
    }

    /**
     * @param $params
     * @return Collection
     */
    public function getCustomFields()
    {
        /** @var ConfigDoppler $dopplerConfig */
        $dopplerConfig = $this->getConfigDoppler()->first();
        $custom_field_doppler = $this->repository->getCustomFields([
            'account' => $dopplerConfig->getAttribute('account'),
            'api_key' => $dopplerConfig->getAttribute('api_key'),
        ]);
        return $custom_field_doppler->get('items');
    }

    /**
     * @param $fields
     * @return mixed
     */
    public function setFiedlMapping($fields)
    {
        return $this->repositoryDatabase->setFiedlMapping($fields);
    }

    /**
     * @return mixed
     */
    public function getFiedlMapping()
    {
        return $this->repositoryDatabase->getFiedlMapping();
    }

    /**
     * @param null $shopId
     * @return mixed
     */
    public function getConfigDoppler($shopId = null)
    {
        return $this->repositoryDatabase->getConfigDoppler($shopId);
    }

    /**
     * @param null $shopId
     * @return mixed
     */
    public function getCurrentSubscriberList($shopId = null)
    {
        return $this->repositoryDatabase->getCurrentSubscriberList($shopId);
    }

    /**
     * @param null $shopId
     * @return mixed
     */
    public function validateCurrentSubscriberListId()
    {
      $valid = true;

      try {
        /** @var CurrentSubscriberList $dopplerConfig */
        $currentList = $this->getCurrentSubscriberList()->first();

        /** @var ConfigDoppler $dopplerConfig */
        $dopplerConfig = $this->getConfigDoppler()->first();

        $listname = $this->repository->getSubscribersListById([
            'account' => $dopplerConfig->getAttribute('account'),
            'api_key' => $dopplerConfig->getAttribute('api_key'),
            'id' => $currentList->getAttribute('list_id'),
        ]);
        $valid = isset($listname);
      } catch (\Exception $e) {
        $valid = false;
      }

      return $valid;
    }

    /**
     * @param $fields
     * @param array $customerHook
     */
    public function synchronizeCustomers($fields, $customerHook = [])
    {
        /** @var ShopifyService $service */
        $service = app(ShopifyService::class);
        $sync_data = $service->synchronizeCustomersData($fields, $customerHook);
        /** @var ConfigDoppler $dopplerConfig */
        $dopplerConfig = $this->getConfigDoppler()->first();
        /** @var CurrentSubscriberList $dopplerConfig */
        $currentList = $this->getCurrentSubscriberList()->first();
        try {
            $result = $this->repository->syncDopplerData([
                'account' => $dopplerConfig->getAttribute('account'),
                'api_key' => $dopplerConfig->getAttribute('api_key'),
                'list_id' => $currentList->getAttribute('list_id'),
                'sync_data' => $sync_data,
            ]);
            if(isset($result['errorCode'])) {
              $errormessage = '';
              switch($result['errorCode']) {
                case 1: $errormessage = 'List is deleted or in a deleting process'; break;
                default: $errormessage = $result['title']; break;
              }
              throw new \Exception($errormessage, $result['errorCode']);
            }
        } catch (\Exception $exception) {
            throw $exception;
        }
        $current_date_time = Carbon::now()->toDateTimeString();
        $dopplerConfig->update([
            'last_sync' => $current_date_time,
            'step' => 'finish',
        ]);
    }

    /**
     * @param array $customerHook
     */
    public function synchronizeCustomersByDb($customerHook = [])
    {
        $dopplerConfig = $this->getConfigDoppler()->first();
        if ($dopplerConfig->getAttribute('sync_process_in_progress') == 'lock') {
            throw new \Exception('ANY_SYNCHRONIZATION_IN_PROCESS');
        }
        $this->repositoryDatabase->processSync('lock');
        try {
            $fieldMapping = $this->getFiedlMapping();
            $this->synchronizeCustomers($fieldMapping, $customerHook);
            $this->repositoryDatabase->processSync('unlock');
        } catch (\Exception $exception) {
            $this->repositoryDatabase->processSync('unlock');
            $dopplerConfig['syncError'] = $exception->getMessage();
            $dopplerConfig['syncErrorCode'] = $exception->getCode();
        }

        return $dopplerConfig;
    }

    public function processSync()
    {
        return $this->repositoryDatabase->processSync();
    }

    public function webhookAppUninstalled($params)
    {
        return $this->repositoryDatabase->uninstallApp($params);
    }

    /**
     * @param $params
     * @return Collection
     */
    public function setIntegrations()
    {
        $config = Config::get('external')['shopify'];
        /** @var User $user */
        $user = User::all()->first();
        /** @var ConfigDoppler $dopplerConfig */
        $dopplerConfig = $this->getConfigDoppler()->first();
        return $this->repository->setIntegrations([
            'api_key' => $dopplerConfig->getAttribute('api_key'),
            'account' => $dopplerConfig->getAttribute('account'),
            'integration_params' => [
                'accountName' => $config['options']['protocol'].$config['options']['base_uri'],
                'accessToken' => $user->getAttribute('password'),
            ],
        ]);
    }

    /**
     * @param $params
     * @return Collection
     */
    public function deleteIntegrations()
    {
        /** @var ConfigDoppler $dopplerConfig */
        $dopplerConfig = $this->getConfigDoppler()->first();
        return $this->repository->deleteIntegrations([
            'api_key' => $dopplerConfig->getAttribute('api_key'),
            'account' => $dopplerConfig->getAttribute('account'),
        ]);
    }

    public function getShopInfo($params)
    {
        $user = app(User::class);
        $shopUser = $user->getShopParameters($params);
        $configDoppler = $this->getConfigDoppler($shopUser['id']);
        $currentList = $this->getCurrentSubscriberList($shopUser['id']);
        $paramsShop = [];
        if (!$configDoppler->isEmpty()) {
            $configDopplerParams = $configDoppler->first()->toArray();
            $currentListParams = [];
            if (!$currentList->isEmpty()) {
                $currentListParams = $currentList->first()->toArray();
            }
            $last_sync = new \DateTime($configDopplerParams['last_sync']);
            $paramsShop = [
                'shopName' => $shopUser['shop_name'],
                //'shopifyAccessToken' => $shopUser['password'],
                'shopifyAccessToken' => '',
                'connectedOn' => $configDopplerParams['created_at'],
                'dopplerListId' => !empty($currentListParams) ? $currentListParams['list_id'] : 'LIST_NOT_CONFIGURED',
                'dopplerListName' => !empty($currentListParams) ? $currentListParams['list_name'] : 'LIST_NOT_CONFIGURED',
                'importedCustomersCount' => $configDopplerParams['customers'],
                'syncProcessDopplerImportSubscribersTaskId' => '',
                'syncProcessInProgress' => $configDopplerParams['sync_process_in_progress'] == 'lock',
                'syncProcessLastRunDate' => $last_sync->format('Y-m-d\TH:i:s.u'),
            ];
        }
        return $paramsShop;
    }

    public function setAllWebhook()
    {
      try
      {
        /** @var ShopifyService $service */
        $service = app(ShopifyService::class);
        $webwooks = Config::get('external')['webhooks'];
        foreach ($webwooks as $webwook) {
            $service->setWebhooks($webwook);
        }
      } catch(\Exception $error) {
        //return true;
      }
    }

    public function getShopShortName($params) {
      try {
        $user = app(User::class);
        $shopname = $user->getShopShortName($params);
        return $shopname;
      } catch (\Exception $e) {
        return '';
      }
    }

    public function getCallBackUrl($params) {
      $user = app(User::class);
      $shopname = $user->getShopShortName($params);
      return "https://".env('DOPPLER_APP_URL')."/authenticatecode/".urlencode($params['email'])."/".$shopname;
    }

    public function getShopifyAppUrl($shop) {
      return "https://".$shop.".myshopify.com/admin/apps/".strtolower(env('SHOPIFY_APP_NAME'));
    }
}
