<?php

namespace App\Providers;

use App\Repositories\DopplerDatabaseRepository;
use App\Repositories\DopplerDatabaseRepositoryInterface;
use App\Repositories\DopplerHTTRepository;
use App\Repositories\DopplerHTTRepositoryInterface;
use App\Repositories\ShopifyHTTRepository;
use App\Repositories\ShopifyHTTRepositoryInterface;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(
            ShopifyHTTRepositoryInterface::class,
            ShopifyHTTRepository::class
        );

        $this->app->bind(
            DopplerHTTRepositoryInterface::class,
            DopplerHTTRepository::class
        );

        $this->app->bind(
            DopplerDatabaseRepositoryInterface::class,
            DopplerDatabaseRepository::class
        );
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
