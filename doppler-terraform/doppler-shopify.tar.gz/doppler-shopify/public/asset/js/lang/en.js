var langtrans = {
  'input_empty': 'Ouch! The field is empty.',
  'invalid_email': 'Ouch! Enter a valid Email.',
  'policy_error': 'Ouch! You haven\'t accepted the Doppler\'s Privacy Policy.',
  'invalid_phone': 'Ouch! Enter a valid phone number.',
};
