var langtrans = {
  'input_empty': '¡Ouch! El campo está vacío.',
  'invalid_email': '¡Ouch! El formato del Email es incorrecto',
  'policy_error': '¡Ouch! No has aceptado la Política de Privacidad de Doppler.',
  'invalid_phone': '¡Ouch! Escribe un teléfono válido.',
};
