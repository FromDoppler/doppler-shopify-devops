var rowHtml = (data,i) => '<tr data-index="'+i+'" class="Polaris-DataTable__TableRow">\n' +
    '            <th class="Polaris-DataTable__Cell Polaris-DataTable__Cell--fixed" scope="row" style="height: 63px;text-transform: capitalize;">'+data['shopify_field']+'</th>\n' +
    '                <td class="Polaris-DataTable__Cell" style="height: 63px;">'+data['doppler_field']+'</td>\n' +
    '                <td class="Polaris-DataTable__Cell" style="height: 63px;">'+data['type']+'</td>\n' +
    '                <td class="Polaris-DataTable__Cell" style="height: 63px;">\n' +
    '                <a id="remove_row" class="Polaris-Button Polaris-Button--sizeSlim Polaris-Button--iconOnly" data-field="'+data['shopify_field']+'" onclick="deleteRow(this)">\n' +
    '                <span class="Polaris-Button__Content">\n' +
    '                <span class="Polaris-Button__Icon">\n' +
    '                <span class="Polaris-Icon">\n' +
    '                <svg class="Polaris-Icon__Svg" viewBox="0 0 20 20" focusable="false" aria-hidden="true">\n' +
    '                <path d="M16 6H4a1 1 0 1 0 0 2h1v9a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V8h1a1 1 0 1 0 0-2zM9 4a1 1 0 1 1 0-2h2a1 1 0 1 1 0 2H9zm2 12h2V8h-2v8zm-4 0h2V8H7v8z" fill-rule="evenodd"></path>\n' +
    '                </svg>\n' +
    '                </span>\n' +
    '                </span>\n' +
    '                </span>\n' +
    '                </a>\n' +
    '                </td>\n' +
    '            </tr>';


var  fieldMapping = fieldMapping ? fieldMapping : null;
var processing = false;

$(document).ready(function(){
    $("#shopify_field").change(function(){
        shopify_field = $(this).val();
        fieldSelected = fieldMapShopify.filter(field => field.name == shopify_field);
        $.post('/selectFieldDoppler?type=' + fieldSelected[0].type, { 'fieldMapping' : fieldMapping}, function(data){
            var doppler_select = '<option value="">Choise</option>'
            for (var i=0; i<data.length; i++)
                doppler_select+='<option value="'+data[i]['name']+'">'+data[i]['name']+'</option>';
            $("#doppler_field").html(doppler_select);
        });
    });

    $('#submitFields').click(function(){
      if(!processing) {
        processing = true;
        $('#submitFields').addClass("Polaris-Button--disabled");
        var sendValue = JSON.stringify(fieldMapping);
        if (sendValue.length === 2){
            $("#msj-error-valid-v1").fadeIn(1500);
            processing = false;
            $('#submitFields').removeClass("Polaris-Button--disabled");
            setTimeout(function() {
                $("#msj-error-valid-v1").fadeOut(1500);
            },5000);
        } else {
            $.post('/setupStepFour',{ 'fields' : sendValue}, function(data){
                console.log(sendValue);
                window.location.href = "/dopplerIndex";
            });
        }
      }
    });

    $("#addField").click(function(e) {
        shopifyField = $('#shopify_field').val()
        dopplerField = $('#doppler_field').val();
        newField = fieldMapShopify.filter(field => field.name == shopifyField);
        fieldSelected = {shopify_field: newField[0].name, path: newField[0].path, doppler_field: dopplerField, type: newField[0].type}
        fieldMapping.push(fieldSelected)
        fieldMapShopify = filterFields(fieldMapShopify);
        $('#field_map').append(rowHtml(fieldSelected, fieldMapping.length - 1))
        makeFieldOptions();
    });

    $("#doppler_field").change(function(){
        $("#addField").removeClass('Polaris-Button--disabled').prop('disabled', false);
    });

    if (fieldMapping) {
        createRows(fieldMapping);
        makeFieldOptions();
    }

    $('#myModal').on('hidden.bs.modal', function (e) {
        clearModal();
    })

    $("#synchronize-customers-btn").click(function (e) {
        e.stopPropagation();
        //TODO Modal, in accept call synchronizeCustomers()

        synchronizeCustomers();
    });
});

function synchronizeCustomers() {
    var btn = $("#synchronize-customers-btn");
    var loading = $(".synchronize .Polaris-Stack.loading");
    var bannerCard = $(".synchronize .Polaris-Banner");
    var ribbonIcon = $(".synchronize .Polaris-Banner__Ribbon");

    loading.removeClass('hide');
    btn.hide();
    bannerCard.removeClass('Polaris-Banner--statusInfo').addClass('Polaris-Banner--statusWarning');
    ribbonIcon.html('<span class="Polaris-Icon Polaris-Icon--colorYellowDark Polaris-Icon--isColored Polaris-Icon--hasBackdrop">\n' +
        '            <svg class="Polaris-Icon__Svg" viewBox="0 0 20 20" focusable="false" aria-hidden="true">\n' +
        '               <path d="M6 10a2 2 0 1 1-4.001-.001A2 2 0 0 1 6 10zm6 0a2 2 0 1 1-4.001-.001A2 2 0 0 1 12 10zm6 0a2 2 0 1 1-4.001-.001A2 2 0 0 1 18 10z" fill-rule="evenodd"></path>\n' +
        '            </svg>\n' +
        '         </span>');
    $(".synchronize #Banner1Content .progress").html('IN PROGRESS');

    $.get('/synchronizeCustomers', function(data){
        loading.addClass('hide');
        btn.show();
        bannerCard.removeClass('Polaris-Banner--statusWarning').addClass('Polaris-Banner--statusInfo');
        ribbonIcon.html('<span class="Polaris-Icon Polaris-Icon--colorTealDark Polaris-Icon--isColored Polaris-Icon--hasBackdrop">\n' +
            '           <svg class="Polaris-Icon__Svg" viewBox="0 0 20 20" focusable="false" aria-hidden="true">\n' +
            '             <path d="M8.315 13.859l-3.182-3.417a.506.506 0 0 1 0-.684l.643-.683a.437.437 0 0 1 .642 0l2.22 2.393 4.942-5.327a.437.437 0 0 1 .643 0l.643.684a.504.504 0 0 1 0 .683l-5.91 6.35a.437.437 0 0 1-.642 0"></path>\n' +
            '           </svg>\n' +
            '        </span>');
        $(".synchronize #Banner1Content .progress").html('COMPLETED');
        $(".synchronize #Banner1Content .last_sync").html(data.data.last_sync);

        if(data.data.syncError && parseInt(data.data.syncErrorCode) == 1 ) {
          $('#myModalInvalidList').modal('toggle');
        }
    });
}

function clearModal() {
    $('#shopify_field, #doppler_field').val('');
    $("#doppler_field").html('');
    $("#addField").addClass('Polaris-Button--disabled').prop('disabled', true);
}

function filterFields(fields) {
    for (const field of fieldMapping) {
        fields = fields.filter((fieldMap) => fieldMap.name != field.shopify_field)
    }
    return fields;
}

function makeFieldOptions() {
    fieldMapShopify = [...fieldMappingShopify];
    fieldMapShopify = filterFields(fieldMapShopify);
    $('#shopify_field').html('<option value="" disabled>Choise Option</option>');
    $('#shopify_field').val('');
    for (const field of fieldMapShopify) {
        $('#shopify_field').append('<option value="' + field['name'] +'">' + field['name'] + '</option>');
    }
}

function deleteRow(row){
    rowDelete = row;
    $('#delete-field').html($(row).attr('data-field'));
    $('#myModalDelete').modal('toggle')
}

function confirmDeleteRow() {
    rowTable = $(rowDelete).parent().parent();
    rowTable.remove();
    index = rowTable.data('index')
    fieldMapping.splice(index,1);
    createRows(fieldMapping)
    makeFieldOptions();
}

function createRows(data) {
    fieldMapping = data;
    $('#field_map').html('');
    for (var i=0; i<data.length; i++)
        $('#field_map').append(rowHtml(data[i],i))
}

function redirectStepThree() {
  window.location.href = "/dopplerIndex";
}
