var current_country = 'iti__ar';

$( document ).ready(function() {
  $(".signup-form #password-field").keydown(function(e) {
    setTimeout(function(){
      validatePassword();
    }, 100);
  });

  initInputsLoginValidation();
  initInputsRegisterValidation();
  initInputsResetPasswordValidation();
});

function flagsToggle() {
  if($('.iti__country-list').css('display') == 'none') {
    $('.iti__country-list').removeClass('iti__hide');
    $('.iti__arrow').addClass('iti__arrow--up');
  } else {
    $('.iti__country-list').addClass('iti__hide');
    $('.iti__arrow').removeClass('iti__arrow--up');
  }
}

function validatePassword() {
  var valid = true;
  validateitem($(".signup-form #password-field").val().length >= 8, 1);
  validateitem(hasNumber($(".signup-form #password-field").val()), 2);
  validateitem(hasChar($(".signup-form #password-field").val()), 3);
  if($('.lack-message').length == 0){
    $('.complete-message').hide();
    $('.secure-message').show();
    $(".signup-form #password-field").parents('.field-item').removeClass('error');
  } else {
    $('.complete-message').show();
    $('.lack-message').show();
    $('.secure-message').hide();
    valid = false;
    $(".signup-form #password-field").parents('.field-item').addClass('error');
  }
  return valid;
}
function validateitem(s, i){
  if(s) {
    $('.password-message span:nth-child('+i+')').removeClass('waiting-message');
    $('.password-message span:nth-child('+i+')').removeClass('lack-message');
    $('.password-message span:nth-child('+i+')').addClass('complete-message');
  } else {
    $('.password-message span:nth-child('+i+')').removeClass('waiting-message');
    $('.password-message span:nth-child('+i+')').removeClass('complete-message');
    $('.password-message span:nth-child('+i+')').addClass('lack-message');
  }
  return s;
}

function hasNumber(s) {
  return /\d/.test(s);
}
function hasChar(s) {
  return /[a-zA-Z]/.test(s);
}

function isEmpty(s) {
  return s.trim() == '';
}

function isEmail(e) {
  const Ht=/^\s*((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\s*$/i,Yt=/^[\u00C0-\u1FFF\u2C00-\uD7FF\w][\u00C0-\u1FFF\u2C00-\uD7FF\w'`\-. ]+$/i,Kt=/[\u00C0-\u00FF]/i;
  return Ht.test(e);
}

function addInputError(i, m) {
  $(i).parents('.field-item').addClass('error');
  $(i).after('<div class="dp-message dp-error-form"><p>'+m+'</p></div>');
}
var vrc = false;
function validateLoginForm() {
  if(!vrc) {

    if(validateInputsLoginForm()) {
      $('.btn-login button').addClass('button--loading');
      $('.btn-login button').attr('disabled', true);
      grecaptcha.execute();
    }
    return false;
  } else {
    return true;
  }
}
function sendLoginForm(data) {
  vrc = true;
  $('#biscolab-recaptcha-invisible-form').submit();
}

function initInputsLoginValidation() {
  $(".login-form #email").keydown(function(e) {
    $(".login-form #email").parents('.field-item').removeClass('error');
    $(".login-form #email").parents('.field-item').find('.dp-message').remove();
  });
  $(".login-form #password-field").keydown(function(e) {
    $(".login-form #password-field").parents('.field-item').removeClass('error');
    $(".login-form #password-field").parents('.field-item').find('.dp-message').remove();
  });
}
function initInputsRegisterValidation() {
  $(".signup-form #firstname").keydown(function(e) {
    $(".signup-form #firstname").parents('.field-item').removeClass('error');
    $(".signup-form #firstname").parents('.field-item').find('.dp-message').remove();
  });
  $(".signup-form #lastname").keydown(function(e) {
    $(".signup-form #lastname").parents('.field-item').removeClass('error');
    $(".signup-form #lastname").parents('.field-item').find('.dp-message').remove();
  });
  $(".signup-form #phone").keydown(function(e) {
    $(".signup-form #phone").parents('.field-item').removeClass('error');
    $(".signup-form #phone").parents('.field-item').find('.dp-message').remove();
  });
  $(".signup-form #email").keydown(function(e) {
    $(".signup-form #email").parents('.field-item').removeClass('error');
    $(".signup-form #email").parents('.field-item').find('.dp-message').remove();
  });
  $(".signup-form #password-field").keydown(function(e) {
    $(".signup-form #password-field").parents('.field-item').removeClass('error');
    $(".signup-form #password-field").parents('.field-item').find('.dp-message').remove();
  });
  $(".signup-form #accept_privacy_policies").change(function(e) {
    $(".signup-form #accept_privacy_policies").parents('.field-item').removeClass('error');
    $(".signup-form #accept_privacy_policies").parents('.field-item').find('.dp-message').remove();
  });
}
function validateInputsLoginForm() {
  var validform = true;
  var email = $('#email').val();
  var pass = $('#password-field').val();

  $('.login-form').find('.dp-message').remove();

  if(isEmpty(email)) {
    validform = false;
    addInputError('#email', langtrans.input_empty);
  } else if(!isEmail(email)) {
    validform = false;
    addInputError('#email', langtrans.invalid_email);
  }
  if(isEmpty(pass)) {
    validform = false;
    addInputError('#password-field', langtrans.input_empty);
  }

  return validform;
}

function validateRegisterForm() {
  if(!vrc) {
    if(validateInputsRegisterForm()) {
      $('.btn-login button').addClass('button--loading');
      $('.btn-login button').attr('disabled', true);
      grecaptcha.execute();
    }
    return false;
  } else {
    return true;
  }
}

function validateInputsRegisterForm() {
  var validform = true;
  var firstname = $('#firstname').val();
  var lastname = $('#lastname').val();
  var phone = $('#phone').val();
  var email = $('#email').val();
  var pass = $('#password-field').val();
  var policy = $('#accept_privacy_policies').prop('checked');

  $('.signup-form').find('.dp-message').remove();

  if(isEmpty(firstname)) {
    validform = false;
    addInputError('#firstname', langtrans.input_empty);
  }
  if(isEmpty(lastname)) {
    validform = false;
    addInputError('#lastname', langtrans.input_empty);
  }
  if(isEmpty(phone)) {
    validform = false;
    addInputError('#phone', langtrans.input_empty);
  } else {

    var input = document.querySelector('#phone');
    var iti = window.intlTelInputGlobals.getInstance(input);
    if(!iti.isValidNumber()) {
      validform = false;
      addInputError('#phone', langtrans.invalid_phone);
    }
  }

  if(isEmpty(email)) {
    validform = false;
    addInputError('#email', langtrans.input_empty);
  } else if(!isEmail(email)) {
    validform = false;
    addInputError('#email', langtrans.invalid_email);
  }

  if(!validatePassword()){
    validform = false;
  }
  if(!policy) {
    validform = false;
    $('#accept_privacy_policies').parents('.field-item').addClass('error');
    $('#accept_privacy_policies').parents('.field-item').find('label').after('<div class="dp-message dp-error-form"><p>'+langtrans.policy_error+'</p></div>');
  }

  return validform;
}

function sendRegisterForm(data) {
  vrc = true;
  $('#biscolab-recaptcha-invisible-form').submit();
}

/*****/

function validateResetPasswordForm() {
  if(!vrc) {

    if(validateInputsResetPasswordForm()) {
      $('.btn-login button').addClass('button--loading');
      $('.btn-login button').attr('disabled', true);
      grecaptcha.execute();
    }
    return false;
  } else {
    return true;
  }
}
function sendResetPasswordForm(data) {
  vrc = true;
  $('#biscolab-recaptcha-invisible-form').submit();
}

function initInputsResetPasswordValidation() {
  $(".login-form #email").keydown(function(e) {
    $(".login-form #email").parents('.field-item').removeClass('error');
    $(".login-form #email").parents('.field-item').find('.dp-message').remove();
  });
}
function validateInputsResetPasswordForm() {
  var validform = true;
  var email = $('#email').val();

  $('.login-form').find('.dp-message').remove();

  if(isEmpty(email)) {
    validform = false;
    addInputError('#email', langtrans.input_empty);
  } else if(!isEmail(email)) {
    validform = false;
    addInputError('#email', langtrans.invalid_email);
  }

  return validform;
}

function sendActivationEmail(email) {
  $('.confirmation-form').append('<input type="hidden" name="email" value="'+email+'">');
  $('.confirmation-form').submit();
}
