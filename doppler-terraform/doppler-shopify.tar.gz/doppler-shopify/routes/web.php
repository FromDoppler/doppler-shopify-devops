<?php

use App\Http\Controllers\ShopifyController;
use App\Http\Controllers\DopplerController;
use App\Http\Controllers\ConfirmationController;
use App\Services\ShopifyService;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|

*/

Route::get('/confirmation', [DopplerController::class, 'confirmation']);

Route::get('/setup', [DopplerController::class, 'setup']);
Route::post('/setupApp', [DopplerController::class, 'setupApp']);
Route::get('/setupStepTwo', [DopplerController::class, 'setupStepTwo']);
Route::get('/setupStepThree', [DopplerController::class, 'setupStepThree']);
Route::post('/setupStepFour', [DopplerController::class, 'setupStepFour']);
Route::post('/createSubscriptionList', [DopplerController::class, 'createSubscriptionList']);
Route::post('/setCurrentSubscriberList', [DopplerController::class, 'setCurrentSubscriberList']);
Route::post('/selectFieldDoppler', [DopplerController::class, 'selectFieldDoppler']);
Route::get('/dopplerIndex', [DopplerController::class, 'dopplerIndex']);
Route::get('/synchronizeCustomers', [DopplerController::class, 'synchronizeCustomers']);
Route::get('/replaceList', [DopplerController::class, 'replaceList']);
Route::get('/fieldsMapping', [DopplerController::class, 'fieldsMapping']);
Route::post('/syncAndReplaceList', [DopplerController::class, 'syncAndReplaceList']);
Route::get('me/shops', [DopplerController::class, 'meShop']);
Route::get('install', [DopplerController::class, 'install']);

//Webhooks
Route::post('/webhookSyncCoustomer', [DopplerController::class, 'webhookSyncCoustomer']);
Route::post('/webhookAppUninstalled', [DopplerController::class, 'webhookAppUninstalled']);
Route::get('/getWebhooks', [DopplerController::class, 'getWebhooks']);
Route::post('/setWebhooks', [DopplerController::class, 'setWebhooks']);

Route::post('/webhookCustomersData', [DopplerController::class, 'webhookCustomersData']);
Route::post('/webhookCustomersRedact', [DopplerController::class, 'webhookCustomersRedact']);
Route::post('/webhookShopRedact', [DopplerController::class, 'webhookShopRedact']);

//Services Rest
Route::get('/getProducts', [DopplerController::class, 'getProducts']);

Route::get('/getSubscribersList', [DopplerController::class, 'getSubscribersList']);
Route::get('/', [DopplerController::class, 'setup'])->middleware(['auth.shop'])->name('home');

Route::get('/login', [DopplerController::class, 'login'])->name('login');
Route::post('/login', [DopplerController::class, 'authenticate']);
Route::get('/register', [DopplerController::class, 'register'])->name('register');
Route::post('/register', [DopplerController::class, 'signup']);
Route::post('/resendactivationemail', [DopplerController::class, 'resendactivationemail']);
Route::get('/resetpassword', [DopplerController::class, 'resetpassword'])->name('resetpassword');
Route::post('/resetpassword', [DopplerController::class, 'sendresetpassword']);

Route::get('/authenticatecode/{email}/{shop}', [DopplerController::class, 'authenticatecode'])->name('authenticatecode');
