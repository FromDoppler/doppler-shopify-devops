<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class CreateConfigDoppler extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('config_dopplers', function (Blueprint $table) {
            $table->id();
            $table->string('account');
            $table->string('api_key')->unique();
            $table->string('sync_process_in_progress');
            $table->timestamp('last_sync')->default(DB::raw('CURRENT_TIMESTAMP'));
            $table->string('step');
            $table->integer('shop_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('config_dopplers');
    }
}
