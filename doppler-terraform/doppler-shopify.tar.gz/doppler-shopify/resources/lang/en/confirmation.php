<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Confirmation View Language
    |--------------------------------------------------------------------------
    */

    'tankyou' => 'Thank you for registering',
    'checkyour' => 'Check your inbox. You have an Email!',
    'note' => '* By clicking on the button from the Email, you will activate your account and you will be ready to enjoy all the benefits of Doppler.',
    'notreceived' => "Haven't you received the Email?",
    'resentit' => 'Resent it.',
    'footerprivacy' => '© 2021 Doppler LLC. All rights reserved. Privacy',
    'footerprivacylink' => 'Policy & Legals.',

];
