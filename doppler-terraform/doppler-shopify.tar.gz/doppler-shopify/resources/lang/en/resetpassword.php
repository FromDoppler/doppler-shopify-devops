<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Login View Language
    |--------------------------------------------------------------------------
    */

    'tittle' => 'FORGOT YOUR PASSWORD?',
    'comment' => 'Don\'t worry! It happens. Enter your Email and we\'ll be glad to help you.',
    'username' => 'Email:',
    'placeholder_user' => 'Psst! Is the same Email you used to create your account',
    'btn_login' => 'REQUEST',
    'btn_back' => 'Did you remember your Password? Go back to Log in.',
    'footer' => 'Site protected by reCAPTCHA and the Google <a target="_blank" href="https://policies.google.com/privacy?hl=en">Privacy Policy</a> and <a target="_blank" href="https://policies.google.com/terms?hl=en">Terms of Service.</a>',
    'footer_small' => '© 2021 Doppler LLC. All rights reserved. <a target="_blank" href="https://www.fromdoppler.com/en/legal/privacidad?utm_source=app&amp;utm_medium=landing&amp;utm_campaign=login">Privacy & Legals</a>.',
    'error_38' => 'Ouch! User does not exist.',
    'error_generic' => '¡Ouch! An unexpected error has occurred. Please, try again.',
    'ok_message_title' => 'Check your inbox!',
    'ok_message_text' => 'You\'ll find an Email with steps to follow.',
    'ok_message_back' => 'Back to Log in',
];
