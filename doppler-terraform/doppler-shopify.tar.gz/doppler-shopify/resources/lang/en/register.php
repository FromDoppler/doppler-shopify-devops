<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Login View Language
    |--------------------------------------------------------------------------
    */

    'tittle' => 'Create your Doppler Account <br>to connect to Shopify',
    'comment' => 'Already have an account? <a href="/login?lang=en">LOG IN</a>',
    'firstname' => 'Name:',
    'lastname' => 'Last name:',
    'phone' => 'Phone:',
    'email' => 'Email:',
    'password' => 'Password:',
    'password_validate_1' => '8 characters minimum',
    'password_validate_2' => 'One number',
    'password_validate_3' => 'One letter',
    'password_validate_4' => 'Your Password is secure!',
    'placeholder_email' => 'Your Email will be your Username',
    'placeholder_pass' => 'Enter your secret key',
    'show_pass' => 'Show',
    'hide_pass' => 'Hide',
    'btn_create' => 'SIGN UP FOR FREE',
    'password_message' => '<p class="password-message"><span class="waiting-message">8 characters minimum</span><span class="waiting-message">One number</span><span class="waiting-message">One letter</span></p>',
    'accept_privacy_policies' => 'I accept Doppler\'s <a target="_blank" href="https://www.fromdoppler.com/en/legal/privacy?utm_source=app&amp;utm_medium=landing&amp;utm_campaign=signup">Privacy Policy</a>.',
    'accept_promotions' => 'Sign me up for promotions about Doppler and allies.',
    'content-legal' => '<p>Doppler informs you that the personal data you provide by completing this form will be treated by Doppler LLC as responsible for this web site.</p><p><strong>Purpose:</strong> Sign you up into our platform and provide the services that you require.</p><p><strong>Legitimation:</strong> Consent of the applicant.</p><p><strong>Recipients:</strong> Your data will be saved by Doppler, Zoho as CRM, Google as the provider of reCAPTCHA service, Digital Ocean, Cogeco Peer1 and Rackspace as hosting companies.</p><p><strong>Additional information:</strong> In Doppler\'s <a target="_blank" href="https://www.fromdoppler.com/en/legal/privacy?utm_source=app&amp;utm_medium=landing&amp;utm_campaign=signup">Privacy Policy</a>
you\'ll find additional information about the data storage and use of your
personal information, including information on access, conservation, rectification,
deletion, security, cross-border data transfers and other issues.</p>',
    'footer_small' => '© 2021 Doppler LLC. All rights reserved. <a target="_blank" href="https://www.fromdoppler.com/en/legal/privacy?utm_source=app&amp;utm_medium=landing&amp;utm_campaign=signup">Privacy Policy &amp; Legals</a>.',
    'error_2' => 'User account is cancelled.',
    'error_4' => 'Email is invalid.',
    'error_37' => 'The email is used by another user.',
    'error_47' => 'The user must read, agree and accept all the terms and conditions.',
    'error_48' => 'The password security level is very low.',
    'error_49' => 'Access denied. Registrations are not allowed.',
    'error_generic' => '¡Ouch! An unexpected error has occurred. Please, try again.',
];
