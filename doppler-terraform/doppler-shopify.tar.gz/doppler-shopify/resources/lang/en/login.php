<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Login View Language
    |--------------------------------------------------------------------------
    */

    'tittle' => 'Sign-in to your Doppler <br> account to connect to Shopify',
    'comment' => 'Don\'t have an account yet? <a href="register?lang=en">SIGN UP FOR FREE</a>',
    'username' => 'Username:',
    'password' => 'Password:',
    'placeholder_user' => 'Psst! It\'s your Email',
    'placeholder_pass' => 'Enter your secret key',
    'show_pass' => 'Show',
    'hide_pass' => 'Hide',
    'btn_login' => 'LOG IN',
    'forgot' => 'Forgot your Password?',
    'footer' => 'Site protected by reCAPTCHA and the Google <a target="_blank" href="https://policies.google.com/privacy?hl=en">Privacy Policy</a> and <a target="_blank" href="https://policies.google.com/terms?hl=en">Terms of Service.</a>',
    'footer_small' => '© 2021 Doppler LLC. All rights reserved. <a target="_blank" href="https://www.fromdoppler.com/en/legal/privacidad?utm_source=app&amp;utm_medium=landing&amp;utm_campaign=login">Privacy & Legals</a>.',
    'error_2' => 'User account is cancelled.',
    'error_50' => 'Ouch! Your account is not active yet, check your email inbox.',
    'error_51' => 'Ouch! There is an error in your Username or Password. Please, try again.',
    'error_generic' => 'Ouch! Something went wrong. Please try again later or <a href="mailto:soporte@fromdoppler.com" target="_blank">contact Customer Support.</a>',
];
