<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Login View Language
    |--------------------------------------------------------------------------
    */

    'tittle' => 'Ingresa a tu cuenta Doppler <br> para conectarte a Shopify',
    'comment' => '¿Aun no tienes cuenta? <a href="register">REGISTRATE GRATIS</a>',
    'username' => 'Nombre de Usuario:',
    'password' => 'Contraseña:',
    'placeholder_user' => '¡Psst! Es tu Email',
    'placeholder_pass' => 'Escribe tu clave secreta',
    'show_pass' => 'Mostrar',
    'hide_pass' => 'Ocultar',
    'btn_login' => 'INGRESA',
    'forgot' => '¿No recuerdas tu Contraseña?',
    'footer' => 'Sitio protegido por reCAPTCHA. <a target="_blank" href="https://policies.google.com/privacy?hl=es">Política de Privacidad</a> y <a target="_blank" href="https://policies.google.com/terms?hl=es">Condiciones del Servicio </a>de Google.',
    'footer_small' => '© 2021 Doppler LLC. Todos los derechos reservados <a target="_blank" href="https://www.fromdoppler.com/legal/privacidad?utm_source=app&amp;utm_medium=landing&amp;utm_campaign=login">Política de Privacidad y Legales</a>.',
    'error_2' => 'La cuenta de este usuario está cancelada.',
    'error_50' => '¡Ouch! Tu cuenta no esta activada, revisa tu correo.',
    'error_51' => '¡Ouch! Hay un error en tu Usuario o Contraseña. Vuelve a intentarlo.',
    'error_generic' => '¡Ouch! Algo salió mal. Por favor, vuelve a intentarlo más tarde o <a href="mailto:soporte@fromdoppler.com" target="_blank">contacta a Atención al Cliente.</a>',
];
