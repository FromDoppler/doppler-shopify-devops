<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Login View Language
    |--------------------------------------------------------------------------
    */

    'tittle' => '¿NO RECUERDAS TU CONTRASEÑA?',
    'comment' => '¡No te preocupes! Nos sucede a todos. Ingresa tu Email y te ayudaremos a recuperarla.',
    'username' => 'Email:',
    'placeholder_user' => '¡Psst! Es el Email con el que creaste tu cuenta',
    'btn_login' => 'SOLICITAR',
    'btn_back' => '¿Recordaste tu Contraseña? ¡Haz clic aquí y vuelve atrás!',
    'footer' => 'Sitio protegido por reCAPTCHA. <a target="_blank" href="https://policies.google.com/privacy?hl=es">Política de Privacidad</a> y <a target="_blank" href="https://policies.google.com/terms?hl=es">Condiciones del Servicio </a>de Google.',
    'footer_small' => '© 2021 Doppler LLC. Todos los derechos reservados <a target="_blank" href="https://www.fromdoppler.com/legal/privacidad?utm_source=app&amp;utm_medium=landing&amp;utm_campaign=login">Política de Privacidad y Legales</a>.',
    'error_38' => '¡Ouch! El usuario no existe.',
    'error_generic' => '¡Ouch! Ha ocurrido un error inesperado. Vuelve a intentarlo.',
    'ok_message_title' => '¡Revisa tu casilla!',
    'ok_message_text' => 'Encontrarás un Email con los pasos a seguir.',
    'ok_message_back' => 'Volver al Log in',
];
