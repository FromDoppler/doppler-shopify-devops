<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Login View Language
    |--------------------------------------------------------------------------
    */

    'tittle' => 'Ingresa a tu cuenta Doppler <br> para conectarte a Shopify',
    'comment' => '¿Ya tienes cuenta? <a href="/login">INGRESA</a>',
    'firstname' => 'Nombre:',
    'lastname' => 'Apellido:',
    'phone' => 'Teléfono:',
    'email' => 'Email:',
    'password' => 'Contraseña:',
    'password_validate_1' => '8 caracteres como mínimo',
    'password_validate_2' => 'Un número',
    'password_validate_3' => 'Una letra',
    'password_validate_4' => '¡Tu Contraseña es segura!',
    'placeholder_email' => 'Tu Email será tu Nombre de Usuario',
    'placeholder_pass' => 'Escribe tu clave secreta',
    'show_pass' => 'Mostrar',
    'hide_pass' => 'Ocultar',
    'btn_create' => 'Crea tu cuenta gratis',
    'password_message' => '<span class="waiting-message">8 caracteres como mínimo</span><span class="waiting-message">Un número</span><span class="waiting-message">Una letra</span>',
    'accept_privacy_policies' => 'Acepto la <a target="_blank" href="https://www.fromdoppler.com/legal/privacidad?utm_source=app&amp;utm_medium=landing&amp;utm_campaign=signup">Política de Privacidad</a> de Doppler.',
    'accept_promotions' => 'Quiero recibir promociones de Doppler y sus aliados.',
    'content-legal' => '<p>Doppler te informa que los datos de carácter personal que nos proporciones al rellenar el presente formulario serán tratados por Doppler LLC como responsable de esta web.</p><p><strong>Finalidad:</strong> Darte de alta en nuestra plataforma y brindarte los servicios que nos requieras..</p><p><strong>Legitimación:</strong> Consentimiento del interesado..</p><p><strong>Destinatarios:</strong> Tus datos serán guardados por Doppler, Zoho como CRM, Google como proveedor del servicio de reCAPTCHA,
        Digital Ocean, Cogeco Peer1 y Rackspace como empresas de hosting.</p><p><strong>Información adicional:</strong> En la <a target="_blank" href="https://www.fromdoppler.com/legal/privacidad?utm_source=app&amp;utm_medium=landing&amp;utm_campaign=signup">Política de Privacidad</a> de Doppler encontrarás información adicional sobre
        la recopilación y el uso de su información personal por parte de Doppler, incluida información sobre acceso, conservación, rectificación,
        eliminación, seguridad, transferencias transfronterizas y otros temas.</p>',
    'footer_small' => '© 2021 Doppler LLC. Todos los derechos reservados. <a target="_blank" href="https://www.fromdoppler.com/legal/privacidad?utm_source=app&amp;utm_medium=landing&amp;utm_campaign=signup">Política de Privacidad y Legales</a>.',
    'error_2' => 'La cuenta de este usuario está cancelada.',
    'error_4' => 'El Email no es válido.',
    'error_37' => 'El correo electrónico es utilizado por otro usuario.',
    'error_47' => 'El usuario debe leer, estar de acuerdo y aceptar todos los términos y condiciones.',
    'error_48' => 'El nivel de seguridad de la contraseña es muy bajo.',
    'error_49' => 'Acceso denegado. No se permiten registraciones.',
    'error_generic' => '¡Ouch! Ha ocurrido un error inesperado. Vuelve a intentarlo.',
];
