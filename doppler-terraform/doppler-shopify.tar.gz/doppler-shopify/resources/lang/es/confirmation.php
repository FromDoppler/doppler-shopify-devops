<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Confirmation View Language
    |--------------------------------------------------------------------------
    */

    'tankyou' => 'Gracias por registrarte',
    'checkyour' => 'Revisa tu casilla. ¡Tienes un Email!',
    'note' => '* Al hacer click en el botón que aparece en el Email, activarás tu cuenta y estarás lista para disfrutar todos los beneficios de  Doppler.',
    'notreceived' => "¿No has recibido el Email?",
    'resentit' => 'Reenvíalo.',
    'footerprivacy' => '© 2021 Doppler LLC. Todos los derechos reservados. Política de',
    'footerprivacylink' => 'Privacidad y Legales.',
];
