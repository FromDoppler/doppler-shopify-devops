@extends('template')
@section('content')
    @include('layouts.setupStepFour')
@endsection
