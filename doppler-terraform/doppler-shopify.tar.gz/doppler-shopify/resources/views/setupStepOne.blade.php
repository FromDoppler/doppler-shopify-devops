@extends('template')
@section('content')
    @include('layouts.setupStepOne')
@endsection
