<!DOCTYPE html>
<html lang="en" xml:lang="en" class="dp-library" data-react-helmet="lang">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <meta name="theme-color" content="#000000">
    <meta name="msapplication-TileColor" content="#fab221">
    <meta name="theme-color" content="#fab221">
    <link rel="stylesheet" href="asset/css/styles.css">
    <link rel="stylesheet" href="asset/css/intlTelInput.css">
    <title>Email Marketing Automation gratis y con envíos ilimitados | Doppler</title>

    {!! htmlScriptTagJsApi(['lang' => 'es']) !!}
</head>
<body class="showZohoTitleDiv" data-react-helmet="class">
<div id="root">
    <div class="dp-app-container">
        <main class="panel-wrapper">
            <article class="main-panel" style="margin: 0 auto;">
                @yield('content')
            </article>
        </main>
    </div>
</div>
</body>
</html>

<script src="asset/js/app.js"></script>
<script src="asset/js/intlTelInput.js"></script>
<script src="asset/js/lang/{{$current_lang}}.js"></script>
<script src="asset/js/login.js"></script>
<script type="text/javascript">
    window.onload = function () {
        var menubutton = new Menubutton(document.getElementById('menubutton'));
        menubutton.init();
    };
    var input = document.querySelector("#phone");
    if(input && $(input).length > 0) {
      window.intlTelInput(input, {
          placeholderNumberType: "MOBILE",
          preferredCountries: ['ar', 'mx', 'co', 'es', 'ec', 'cl', 'pe', 'us'],
          utilsScript: "asset/js/utils.js",
      });
    }
</script>
