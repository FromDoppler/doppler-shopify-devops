@extends('template')
@section('content')
    @include('layouts/doppler')
@endsection
