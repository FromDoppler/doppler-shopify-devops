@extends('template_user')
@section('content')
    @include('layouts/user/resetpassword')
@endsection
