
<!-- Modal -->
<div class="modal2 fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document" style="top: 10%;">
        <div class="styles_modal__gNwvD styles_modalCenter__L9F2w" role="dialog" aria-modal="true">
            <div>
                <div>
                    <div class="Polaris-Layout">
                        <div class="Polaris-Layout__Section">
                            <div class="Polaris-Card">
                                <div class="Polaris-Card__Header">
                                    <h2 class="Polaris-Heading">Add new Field</h2>
                                </div>
                                <div class="Polaris-Card__Section">
                                    <p>Select the Shopify Field you'd like to assign to a Doppler Field.</p>
                                    <p>Keep in mind that only Fields of the same type can be assigned.</p>
                                    <br>
                                    <div class="Polaris-FormLayout">
                                        <div class="Polaris-FormLayout__Item">
                                            <div class="">
                                                <div class="Polaris-Labelled__LabelWrapper">
                                                    <div class="Polaris-Label"><label id="Select47Label" for="Select47" class="Polaris-Label__Text">Shopify Customer Field</label></div>
                                                </div>
                                                <div class="Polaris-Select">
                                                    <select name="shopify_field" id="shopify_field" class="form-control" aria-describedby="selectHelp">
                                                        <option value="" disabled>Choise Option</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="Polaris-FormLayout__Item">
                                            <div class="">
                                                <div class="Polaris-Labelled__LabelWrapper">
                                                    <div class="Polaris-Label"><label id="Select48Label" for="Select48" class="Polaris-Label__Text">Doppler Subscriber Field</label></div>
                                                </div>
                                                <div class="Polaris-Select">
                                                    <select name="doppler_field" id="doppler_field" class="form-control" aria-describedby="selectHelp">
                                                        <option value="" disabled>Choise Option</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="Polaris-FormLayout__Item">
                                            <div class="Polaris-Stack Polaris-Stack--distributionTrailing Polaris-Stack--alignmentCenter">
                                                <div class="Polaris-Stack__Item">
                                                    <div class="Polaris-ButtonGroup">
                                                        <div class="Polaris-ButtonGroup__Item"><button data-dismiss="modal" class="Polaris-Button"><span class="Polaris-Button__Content"><span>Cancel</span></span></button></div>
                                                        <div class="Polaris-ButtonGroup__Item"><button data-dismiss="modal" id="addField" class="Polaris-Button Polaris-Button--primary Polaris-Button--disabled" disabled><span class="Polaris-Button__Content"><span>Save</span></span></button></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .modal-header2 {
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-align: start;
        -ms-flex-align: start;
        align-items: flex-start;
        -webkit-box-pack: justify;
        -ms-flex-pack: justify;
        justify-content: space-between;
        padding: 1rem;
        border-bottom: 1px solid #e9ecef;
        border-top-left-radius: .3rem;
        border-top-right-radius: .3rem;
    }
    .modal-title2 {
        margin-bottom: 0;
        line-height: 1.5;
    }
    .modal2 {
        background: rgba(0, 0, 0, 0.75);
        position: fixed;
        top: 0%;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: 1050;
        display: none;
        -webkit-overflow-scrolling: touch;
        outline: 0;
    }
</style>
