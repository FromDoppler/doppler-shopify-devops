@if($isSetup)
<div class="polaris-progress">
    <progress class="polaris-progress__progress" value="50" max="100"></progress>
    <div class="polaris-progress__bar" style="width:100%"></div>
</div>
@endif
<div id="root">
    <div class="Polaris-Page">
        <div class="Polaris-Page__Content">
                <div id="type-container">
                    <div id="msj-error-valid-v1" class="alert alert-danger alert-dismissible" role="alert" style="display:none">
                        <strong id="msj_v1">Add new field</strong>
                    </div>
                    <div class="Polaris-Layout">
                        <div class="Polaris-Layout__Section">
                            <div class="Polaris-Card">
                                <div class="Polaris-Card__Header">
                                    <h2 class="Polaris-Heading">Map the Fields of your Shopify customers</h2>
                                </div>
                                <div class="Polaris-Card__Section">
                                    <p>Select the Doppler Field you'd like to assign to each Shopify field. For each new customer, a new Subscriber will be created based on this mapping. Keep in mind that you need to create Custom Fields previously in your Doppler account.</p>
                                    <br>
                                    <div class="">
                                        <div class="Polaris-DataTable__Navigation">
                                            <button type="button" class="Polaris-Button Polaris-Button--disabled Polaris-Button--plain Polaris-Button--iconOnly" disabled="" aria-label="Scroll table left one column">
                                                 <span class="Polaris-Button__Content">
                                                    <span class="Polaris-Button__Icon">
                                                       <span class="Polaris-Icon">
                                                          <svg class="Polaris-Icon__Svg" viewBox="0 0 20 20" focusable="false" aria-hidden="true">
                                                             <path d="M12 16a.997.997 0 0 1-.707-.293l-5-5a.999.999 0 0 1 0-1.414l5-5a.999.999 0 1 1 1.414 1.414L8.414 10l4.293 4.293A.999.999 0 0 1 12 16" fill-rule="evenodd"></path>
                                                          </svg>
                                                       </span>
                                                    </span>
                                                 </span>
                                            </button>
                                            <button type="button" class="Polaris-Button Polaris-Button--plain Polaris-Button--iconOnly" aria-label="Scroll table right one column">
                                                 <span class="Polaris-Button__Content">
                                                    <span class="Polaris-Button__Icon">
                                                       <span class="Polaris-Icon">
                                                          <svg class="Polaris-Icon__Svg" viewBox="0 0 20 20" focusable="false" aria-hidden="true">
                                                             <path d="M8 16a.999.999 0 0 1-.707-1.707L11.586 10 7.293 5.707a.999.999 0 1 1 1.414-1.414l5 5a.999.999 0 0 1 0 1.414l-5 5A.997.997 0 0 1 8 16" fill-rule="evenodd"></path>
                                                          </svg>
                                                       </span>
                                                    </span>
                                                 </span>
                                            </button>
                                        </div>
                                        <div class="Polaris-DataTable">
                                            <div class="Polaris-DataTable__ScrollContainer">
                                                <table class="Polaris-DataTable__Table">
                                                    <thead>
                                                    <tr>
                                                        <th class="Polaris-DataTable__Cell Polaris-DataTable__Cell--fixed Polaris-DataTable__Cell--header" scope="col">Shopify</th>
                                                        <th class="Polaris-DataTable__Cell Polaris-DataTable__Cell--header" scope="col" style="height: 54px;">Doppler</th>
                                                        <th class="Polaris-DataTable__Cell Polaris-DataTable__Cell--header" scope="col" style="height: 54px;">Field Type</th>
                                                        <th class="Polaris-DataTable__Cell Polaris-DataTable__Cell--header" scope="col" style="height: 54px;"></th>
                                                    </tr>
                                                    </thead>
                                                    <tbody id="field_map">
                                                    <tr class="Polaris-DataTable__TableRow">
                                                        <th class="Polaris-DataTable__Cell Polaris-DataTable__Cell--fixed" scope="row" style="height: 53px;"><strong>Email</strong></th>
                                                        <td class="Polaris-DataTable__Cell" style="height: 53px;"><strong>EMAIL</strong></td>
                                                        <td class="Polaris-DataTable__Cell" style="height: 53px;">string</td>
                                                        <td class="Polaris-DataTable__Cell" style="height: 53px;"></td>
                                                    </tr>

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="margin-top: 2rem;">
                        <div class="Polaris-Stack">
                            <div class="Polaris-Stack__Item Polaris-Stack__Item--fill">
                                <button type="button" class="Polaris-Button" data-toggle="modal" data-target="#myModal">
                                <span class="Polaris-Button__Content">
                                   <span class="Polaris-Button__Icon">
                                      <span class="Polaris-Icon">
                                         <svg class="Polaris-Icon__Svg" viewBox="0 0 20 20" focusable="false" aria-hidden="true">
                                            <path d="M17 9h-6V3a1 1 0 1 0-2 0v6H3a1 1 0 1 0 0 2h6v6a1 1 0 1 0 2 0v-6h6a1 1 0 1 0 0-2" fill-rule="evenodd"></path>
                                         </svg>
                                      </span>
                                   </span>
                                   <span>Add new Field</span>
                                </span>
                                </button>
                            </div>
                            <div class="Polaris-Stack__Item">
                                <div class="Polaris-ButtonGroup">
                                    @if(!$isSetup)
                                    <div class="Polaris-ButtonGroup__Item"><a href="/dopplerIndex" class="Polaris-Button"><span class="Polaris-Button__Content"><span>Cancel</span></span></a></div>
                                    @endif
                                    <div class="Polaris-ButtonGroup__Item"><button id="submitFields" class="Polaris-Button Polaris-Button--primary"><span class="Polaris-Button__Content"><span>Save</span></span></button></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="Polaris-FooterHelp">
                        <div class="Polaris-FooterHelp__Content">
                            <div class="Polaris-FooterHelp__Icon">
                             <span class="Polaris-Icon Polaris-Icon--colorTeal Polaris-Icon--isColored Polaris-Icon--hasBackdrop">
                                <svg class="Polaris-Icon__Svg" viewBox="0 0 20 20" focusable="false" aria-hidden="true">
                                   <circle cx="10" cy="10" r="9" fill="currentColor"></circle>
                                   <path d="M10 0C4.486 0 0 4.486 0 10s4.486 10 10 10 10-4.486 10-10S15.514 0 10 0m0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8 8 3.589 8 8-3.589 8-8 8m0-4a1 1 0 1 0 0 2 1 1 0 1 0 0-2m0-10C8.346 4 7 5.346 7 7a1 1 0 1 0 2 0 1.001 1.001 0 1 1 1.591.808C9.58 8.548 9 9.616 9 10.737V11a1 1 0 1 0 2 0v-.263c0-.653.484-1.105.773-1.317A3.013 3.013 0 0 0 13 7c0-1.654-1.346-3-3-3"></path>
                                </svg>
                             </span>
                            </div>
                            <div class="Polaris-FooterHelp__Text">Need to create a Custom Field in Doppler? Check <a target="_blank" class="Polaris-Link" href="https://help.fromdoppler.com/en/how-to-create-a-customized-field/?utm_source=integracion&amp;utm_medium=integracion&amp;utm_campaign=shopify" rel="noopener noreferrer" data-polaris-unstyled="true">this tutorial</a>.</div>
                        </div>
                    </div>
                </div>
        </div>
    </div>
</div>
@include('layouts.modal_field_mapping')
@include('layouts.modal_confirm_delete')
@include('layouts.modal_invalid_list')

<script>
   var  fieldMappingShopify = {!! json_encode($field_mapping_shopify) !!}
   var  fieldMapping = {!! json_encode($field_mapping) !!}
   var  rowDelete = null;
   var  fieldMapShopify = [];
   @if(!($list_valid??true))
   $('#myModalInvalidList').modal('toggle');
   @endif
</script>
