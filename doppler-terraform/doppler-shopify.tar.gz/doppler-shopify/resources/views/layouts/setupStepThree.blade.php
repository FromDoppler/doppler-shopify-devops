@if($isSetup)
    <div class="polaris-progress">
        <progress class="polaris-progress__progress" value="50" max="100"></progress>
        <div class="polaris-progress__bar" style="width:75%"></div>
    </div>
@endif
<div id="root">
    <div class="Polaris-Page">
        <div class="Polaris-Page__Content">
            <div>
                <div class="Polaris-Layout">
                    <form action="/setCurrentSubscriberList" onsubmit="return validateListForm();" method="POST">
                        {{csrf_field()}}
                        <div class="Polaris-Layout__Section">
                          @if ($errors->any())
                              <div class="dp-alert dp-alert-danger">
                                  <ul>
                                      @foreach ($errors->all() as $error)
                                          <li>{{ $error }}</li>
                                      @endforeach
                                  </ul>
                              </div>
                          @endif
                            <div id="Polaris-Card-List" class="Polaris-Card">
                                <div class="Polaris-Card__Header">
                                    <h2 class="Polaris-Heading">Sync your store to a Doppler List</h2>
                                </div>
                                <div class="Polaris-Card__Section">
                                    <div class="Polaris-TextContainer Polaris-TextContainer--spacingLoose">
                                        <p><strong>Your Doppler account is now connected.</strong> Start by associating your customers to your Lists, so you can trigger customized and targeted Automation Emails based on a specific date, event, or their activity on your Campaigns or Website.</p>
                                        <div class="Polaris-Banner Polaris-Banner--statusWarning Polaris-Banner--withinContentContainer hidden" tabindex="0" role="alert" aria-live="polite" aria-describedby="Banner11Content">
                                            <div class="Polaris-Banner__Ribbon">
                                                 <span class="Polaris-Icon Polaris-Icon--colorYellowDark Polaris-Icon--isColored Polaris-Icon--hasBackdrop">
                                                    <svg class="Polaris-Icon__Svg" viewBox="0 0 20 20" focusable="false" aria-hidden="true">
                                                       <g fill-rule="evenodd">
                                                          <circle fill="currentColor" cx="10" cy="10" r="9"></circle>
                                                          <path d="M10 0C4.486 0 0 4.486 0 10s4.486 10 10 10 10-4.486 10-10S15.514 0 10 0m0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8m0-13a1 1 0 0 0-1 1v4a1 1 0 1 0 2 0V6a1 1 0 0 0-1-1m0 8a1 1 0 1 0 0 2 1 1 0 0 0 0-2"></path>
                                                       </g>
                                                    </svg>
                                                 </span>
                                            </div>
                                            <div>
                                                <div class="Polaris-Banner__Content" id="Banner11Content">
                                                    <p>All existing subscribers in the selected List will be desassociated from it.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Select a Subscribers List to sync to your store:</p>
                                        <div class="">
                                            <div class="Polaris-Select">
                                                <select class="form-control" name="list" id="subscriber_list">
                                                  @if(isset($subscribersList))
                                                    @foreach($subscribersList as $list)
                                                        <option id="list_id" value="<?php echo htmlspecialchars( json_encode(['list_id' => $list->listId, 'list_name' => $list->name]), ENT_COMPAT ); ?>">{{$list->name}}</option>
                                                    @endforeach
                                                  @endif
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div style="margin-top: 2rem;">
                                <div class="Polaris-Stack">
                                    <div class="Polaris-Stack__Item Polaris-Stack__Item--fill">
                                        <button type="button" class="Polaris-Button" data-toggle="modal" data-target="#myModal">
                                            <span class="Polaris-Button__Content">
                                                <span class="Polaris-Button__Icon">
                                                    <span class="Polaris-Icon">
                                                        <svg class="Polaris-Icon__Svg" viewBox="0 0 20 20" focusable="false" aria-hidden="true">
                                                            <path d="M17 9h-6V3a1 1 0 1 0-2 0v6H3a1 1 0 1 0 0 2h6v6a1 1 0 1 0 2 0v-6h6a1 1 0 1 0 0-2" fill-rule="evenodd"></path>
                                                        </svg>
                                                    </span>
                                                </span>
                                                <span>Create new List</span>
                                            </span>
                                        </button>
                                    </div>
                                    <div class="Polaris-Stack__Item">
                                        <div class="Polaris-ButtonGroup">
                                            @if(!$isSetup)
                                                @if($listConfigured)
                                                    <div class="Polaris-ButtonGroup__Item"><a href="/dopplerIndex" class="Polaris-Button"><span class="Polaris-Button__Content"><span>Cancel</span></span></a></div>
                                                @endif
                                                <div class="Polaris-ButtonGroup__Item"><a id="submitReplaceList" style="color: white;" class="Polaris-Button Polaris-Button--primary"><span class="Polaris-Button__Content"><span>Save</span></span></a></div>
                                            @else
                                                <div class="Polaris-ButtonGroup__Item"><button id="submitSetupBtn" type="submit" class="Polaris-Button Polaris-Button--primary"><span class="Polaris-Button__Content"><span>Save</span></span></button></div>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="Polaris-FooterHelp">
                    <div class="Polaris-FooterHelp__Content">
                        <div class="Polaris-FooterHelp__Icon">
                     <span class="Polaris-Icon Polaris-Icon--colorTeal Polaris-Icon--isColored Polaris-Icon--hasBackdrop">
                        <svg class="Polaris-Icon__Svg" viewBox="0 0 20 20" focusable="false" aria-hidden="true">
                           <circle cx="10" cy="10" r="9" fill="currentColor"></circle>
                           <path d="M10 0C4.486 0 0 4.486 0 10s4.486 10 10 10 10-4.486 10-10S15.514 0 10 0m0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8 8 3.589 8 8-3.589 8-8 8m0-4a1 1 0 1 0 0 2 1 1 0 1 0 0-2m0-10C8.346 4 7 5.346 7 7a1 1 0 1 0 2 0 1.001 1.001 0 1 1 1.591.808C9.58 8.548 9 9.616 9 10.737V11a1 1 0 1 0 2 0v-.263c0-.653.484-1.105.773-1.317A3.013 3.013 0 0 0 13 7c0-1.654-1.346-3-3-3"></path>
                        </svg>
                     </span>
                        </div>
                        <div class="Polaris-FooterHelp__Text">Check <a target="_blank" class="Polaris-Link" href="https://help.fromdoppler.com/en/guide-to-managing-your-subscribers-lists/?utm_source=integracion&amp;utm_medium=integracion&amp;utm_campaign=shopify" rel="noopener noreferrer" data-polaris-unstyled="true">these tips</a> for managing your Lists.</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@include('layouts.modal_subscriber_list')

<script>
    var list = $('#list_id').val();

    $("#subscriber_list").change(function(){
        list = $(this).val();
    });
    var processing = false;
    $(document).ready(function(){
        $('#submitReplaceList').click(function(){
          if(!processing) {
            $('.dp-alert').remove();
            processing = true;
            $('#submitReplaceList').addClass("Polaris-Button--disabled");
            $.post('/syncAndReplaceList',{ 'list' : list}, function(data){
              if(data.status == 'OK') {
                window.location.href = "/dopplerIndex";
              } else {
                $('#Polaris-Card-List').before('<div class="dp-alert dp-alert-danger"><ul><li>'+data.errorMessage+'</li></ul></div>');
                processing = false;
                $('#submitReplaceList').removeClass("Polaris-Button--disabled");
              }
            });
          }
        });
    });
    function validateListForm(){
      if(!processing) {
        processing = true;
        $('#submitSetupBtn').addClass("Polaris-Button--disabled");
        return true;
      } else {
        return false;
      }
    }
</script>
