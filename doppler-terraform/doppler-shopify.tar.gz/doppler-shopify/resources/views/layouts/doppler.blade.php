<div id="root">
<div class="Polaris-Page">
    <div class="Polaris-Page__Content">
        <div>
          @if ($errors->any())
              <div class="dp-alert dp-alert-danger">
                  <ul>
                      @foreach ($errors->all() as $error)
                          <li>{{ $error }}</li>
                      @endforeach
                  </ul>
              </div>
          @endif
            <div class="Polaris-Card">
                <div>
                    <ul role="tablist" class="Polaris-Tabs Polaris-Tabs--fitted">
                        <li role="presentation" class="Polaris-Tabs__TabContainer"><button id="customers-synchronization-setup" role="tab" type="button" tabindex="0" class="Polaris-Tabs__Tab Polaris-Tabs__Tab--selected" aria-selected="true" aria-controls="customers-synchronization-setup" aria-label="Customers Synchronization Setup"><span class="Polaris-Tabs__Title">Customers Synchronization Setup</span></button></li>
                        <li role="presentation" class="Polaris-Tabs__DisclosureTab">
                            <div>
                                <button tabindex="-1" class="Polaris-Tabs__DisclosureActivator" aria-controls="Popover1" aria-owns="Popover1" aria-haspopup="true" aria-expanded="false">
                                   <span class="Polaris-Icon">
                                      <svg class="Polaris-Icon__Svg" viewBox="0 0 20 20" focusable="false" aria-hidden="true">
                                         <path d="M6 10a2 2 0 1 1-4.001-.001A2 2 0 0 1 6 10zm6 0a2 2 0 1 1-4.001-.001A2 2 0 0 1 12 10zm6 0a2 2 0 1 1-4.001-.001A2 2 0 0 1 18 10z" fill-rule="evenodd"></path>
                                      </svg>
                                   </span>
                                </button>
                            </div>
                        </li>
                    </ul>
                    <div class="Polaris-Tabs Polaris-Tabs__TabMeasurer">
                        <li role="presentation" class="Polaris-Tabs__TabContainer"><button id="customers-synchronization-setupMeasurer" role="tab" type="button" tabindex="-1" class="Polaris-Tabs__Tab Polaris-Tabs__Tab--selected" aria-selected="true"><span class="Polaris-Tabs__Title">Customers Synchronization Setup</span></button></li>
                        <button tabindex="-1" class="Polaris-Tabs__DisclosureActivator">
                             <span class="Polaris-Icon">
                                <svg class="Polaris-Icon__Svg" viewBox="0 0 20 20" focusable="false" aria-hidden="true">
                                   <path d="M6 10a2 2 0 1 1-4.001-.001A2 2 0 0 1 6 10zm6 0a2 2 0 1 1-4.001-.001A2 2 0 0 1 12 10zm6 0a2 2 0 1 1-4.001-.001A2 2 0 0 1 18 10z" fill-rule="evenodd"></path>
                                </svg>
                             </span>
                        </button>
                    </div>
                </div>
                <div class="Polaris-Card__Section">
                    <div>
                        <div class="Polaris-Layout">
                            <div class="Polaris-Layout__Section">
                                <div class="Polaris-Card synchronize">
                                    <div class="Polaris-Card__Header">
                                        <h2 class="Polaris-Heading">Customers Synchronization</h2>
                                    </div>
                                    <div class="Polaris-Card__Section">
                                        <p>Shopify is connected with  <strong>{{$dopplerConfig['account']}}</strong>'s Doppler account. Every new customer will automatically be added as a Doppler Subscriber in the List you’ve selected. If you wish to add all the customers you currently have in Shopify to this Doppler List, run the synchronization process.</p>
                                        <br>
                                        <div>
                                            <div class="Polaris-Banner Polaris-Banner--statusInfo Polaris-Banner--withinContentContainer" tabindex="0" role="status" aria-live="polite" aria-describedby="Banner1Content">
                                                <div class="Polaris-Banner__Ribbon">
                                                   <span class="Polaris-Icon Polaris-Icon--colorTealDark Polaris-Icon--isColored Polaris-Icon--hasBackdrop">
                                                      <svg class="Polaris-Icon__Svg" viewBox="0 0 20 20" focusable="false" aria-hidden="true">
                                                         <path d="M8.315 13.859l-3.182-3.417a.506.506 0 0 1 0-.684l.643-.683a.437.437 0 0 1 .642 0l2.22 2.393 4.942-5.327a.437.437 0 0 1 .643 0l.643.684a.504.504 0 0 1 0 .683l-5.91 6.35a.437.437 0 0 1-.642 0"></path>
                                                      </svg>
                                                   </span>
                                                </div>
                                                <div>
                                                    <div class="Polaris-Banner__Content" id="Banner1Content">
                                                        <p>Synchronization process status: <strong class="progress">COMPLETED</strong></p>
                                                        <p>Requested on: <strong class="last_sync">{{$dopplerConfig['last_sync']}}</strong></p>
                                                    </div>
                                                </div>
                                            </div>
                                            <br>
                                        </div>
                                        <div class="Polaris-Stack loading hide">
                                            <div class="Polaris-Stack__Item">
                                                <svg viewBox="0 0 20 20" class="Polaris-Spinner Polaris-Spinner--colorTeal Polaris-Spinner--sizeSmall" role="status">
                                                    <path d="M7.229 1.173a9.25 9.25 0 1 0 11.655 11.412 1.25 1.25 0 1 0-2.4-.698 6.75 6.75 0 1 1-8.506-8.329 1.25 1.25 0 1 0-.75-2.385z"></path>
                                                </svg>
                                            </div>
                                            <div class="Polaris-Stack__Item">
                                                <p>Synchronizing...</p>
                                            </div>
                                        </div>
                                        <btn id="synchronize-customers-btn" class="Polaris-Button Polaris-Button--primary"><span class="Polaris-Button__Content"><span>Synchronize Customers</span></span></btn>
                                    </div>
                                </div>
                            </div>
                            <form action="/replaceList" method="GET">
                                <div class="Polaris-Layout__Section">
                                    <div class="Polaris-Card">
                                        <div class="Polaris-Card__Header">
                                            <h2 class="Polaris-Heading">Subscribers List</h2>
                                        </div>
                                        <div class="Polaris-Card__Section">
                                            <p>You have currently configured the <strong>{{$dopplerConfig['list_name']}}</strong> List. This is where all the new Subscribers will be added. If you want to change the selected List or create a new one click the <i>Replace List</i> button.</p>
                                            <br><button type="submit" class="Polaris-Button Polaris-Button--primary"><span class="Polaris-Button__Content"><span>Replace List</span></span></button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <form action="/fieldsMapping" method="GET">
                                <div class="Polaris-Layout__Section">
                                    <div class="Polaris-Card">
                                        <div class="Polaris-Card__Header">
                                            <h2 class="Polaris-Heading">Fields Mapping</h2>
                                        </div>
                                        <div class="Polaris-Card__Section">
                                            <p>Choose what Fields you want to assign from a customer to a Subscriber in order to collect all the information that you need for your Doppler Campaigns: names, addresses, phone numbers, etc.</p>
                                            <br><button type="submit" class="Polaris-Button Polaris-Button--primary"><span class="Polaris-Button__Content"><span>Set up Fields Mapping</span></span></button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="Polaris-FooterHelp">
                <div class="Polaris-FooterHelp__Content">
                    <div class="Polaris-FooterHelp__Icon">
                  <span class="Polaris-Icon Polaris-Icon--colorTeal Polaris-Icon--isColored Polaris-Icon--hasBackdrop">
                     <svg class="Polaris-Icon__Svg" viewBox="0 0 20 20" focusable="false" aria-hidden="true">
                        <circle cx="10" cy="10" r="9" fill="currentColor"></circle>
                        <path d="M10 0C4.486 0 0 4.486 0 10s4.486 10 10 10 10-4.486 10-10S15.514 0 10 0m0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8 8 3.589 8 8-3.589 8-8 8m0-4a1 1 0 1 0 0 2 1 1 0 1 0 0-2m0-10C8.346 4 7 5.346 7 7a1 1 0 1 0 2 0 1.001 1.001 0 1 1 1.591.808C9.58 8.548 9 9.616 9 10.737V11a1 1 0 1 0 2 0v-.263c0-.653.484-1.105.773-1.317A3.013 3.013 0 0 0 13 7c0-1.654-1.346-3-3-3"></path>
                     </svg>
                  </span>
                    </div>
                    <div class="Polaris-FooterHelp__Text">Any questions? <a target="_blank" class="Polaris-Link" href="mailto:support@fromdoppler.com" rel="noopener noreferrer" data-polaris-unstyled="true">Contact</a> us!</div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
@include('layouts.modal_invalid_list')
