<div class="dp-c-dropdown language-selector">
    <button class="lang--{{$current_lang}}" id="menubutton" aria-haspopup="true" aria-controls="menu2">{{$current_lang}}</button>
    <ul id="menu2" role="menu" aria-labelledby="menubutton" tabindex="-1">
        <li role="none">
            <a role="menuitem" href="/login?lang={{$secundary_lang}}" class="lang--{{$secundary_lang}}" tabindex="-1">{{$secundary_lang}}</a>
        </li>
    </ul>
</div>

<header>
    <div class="logo-doppler-new"><a target="_blank" href="https://www.fromdoppler.com/{{$current_lang}}/?utm_source=app&amp;utm_medium=landing&amp;utm_campaign=login" rel="noopener noreferrer">Doppler</a></div>
    <hr class="name-of-your-vertical-line"/>
    <div class="shopify-class">
        <img src="asset/images/a67335211.jpg" alt=""> <span>{{$shopname}}</span>
    </div>
</header>
<h1>{!!trans('login.tittle')!!}</h1>
<div align="center">
    <p class="content-subtitle">{!! trans('login.comment') !!}</p>
</div>
<form id="{{ getFormId() }}" method="POST" novalidate="true" onsubmit="return validateLoginForm();" action="login?lang={{$current_lang}}" class="login-form">
  {{csrf_field()}}
    <fieldset>
        <ul class="field-group">
            <li class="field-item">
                <label for="email">{{trans('login.username')}}</label>
                <input type="email" name="email" id="email" maxlength="100" value="{{old('email')}}" required placeholder="{{trans('login.placeholder_user')}}">
            </li>
            <li class="field-item">
                <label for="password">{{trans('login.password')}}
                    <a toggle="#password-field" class="ms-icon icon-view show-hide">
                        <span class="content-eye" text-hide="{{trans('login.hide_pass')}}" text-show="{{trans('login.show_pass')}}">{{trans('login.show_pass')}}</span></a></label>
                <input type="password" name="password" id="password-field" maxlength="20" value="{{old('password')}}" required placeholder="{{trans('login.placeholder_pass')}}">
            </li>
        </ul>
    </fieldset>
    @if(isset($errors) && count($errors->all()) > 0)
    <fieldset>
      <div class="form-message bounceIn dp-error"><div><p>
          @foreach ($errors->all() as $error)
              {!! $error !!}
          @endforeach
          </p></div>
      </div>
    </fieldset>
    @endif
    <fieldset class="btn-login">
        <div class="g-recaptcha"
             data-sitekey="{{ env('RECAPTCHA_SITE_KEY') }}"
             data-size="invisible"
             data-callback="sendLoginForm">
        </div>
        <button type="submit" class="dp-button button-medium primary-green button--round">{{trans('login.btn_login')}}</button>
        <a class="forgot-link" href="/resetpassword?lang={{$current_lang}}">{{trans('login.forgot')}}</a>
    </fieldset>
</form>

<footer>
    <div class="captcha-legal-message">
        <p>{!!trans('login.footer')!!}</p>
    </div>
    <small>
        <p>{!!trans('login.footer_small')!!}</p>
    </small>
</footer>
