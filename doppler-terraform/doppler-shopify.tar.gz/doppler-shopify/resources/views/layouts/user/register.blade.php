@include('layouts/components/lang')
@include('layouts/components/header_user')
<h1>{!!trans('login.tittle')!!}</h1>
<div align="center">
    <p class="content-subtitle">{!! trans('register.comment') !!}</p>
</div>
<form id="{{ getFormId() }}" method="POST" novalidate="true" action="register?lang={{$current_lang}}" onsubmit="return validateRegisterForm()" class="signup-form">
  {{csrf_field()}}
    <fieldset>
        <ul class="field-group">
            <li class="field-item field-item--50"><label for="firstname">{{trans('register.firstname')}} </label><input name="firstname" type="text" id="firstname" maxlength="100" value="{{ old('firstname') }}" required></li>
            <li class="field-item field-item--50"><label for="lastname">{{trans('register.lastname')}} </label><input name="lastname" type="text" id="lastname" maxlength="100" value="{{ old('lastname') }}" required></li>
            <li class="field-item">
                <label for="phone">{{trans('register.phone')}} </label>
                <input name="phone" type="tel" id="phone" maxlength="100" value="{{ old('phone') }}" required>
            </li>
        </ul>
    </fieldset>
    <fieldset>
        <ul class="field-group">
            <li class="field-item"><label for="email">{{trans('register.email')}} </label><input name="email" type="text" id="email" placeholder="{{trans('register.placeholder_email')}}" maxlength="200" value="{{ old('email') }}" required></li>
            <li class="field-item">
                <label for="password">{{trans('register.password')}}
                  <a toggle="#password-field" class="ms-icon icon-view show-hide">
                      <span class="content-eye" text-hide="{{trans('register.hide_pass')}}" text-show="{{trans('register.show_pass')}}">{{trans('register.show_pass')}}</span></a>
                </label>
                <input name="password" type="password" autocomplete="current-password" maxlength="20" id="password-field" placeholder="{{trans('register.placeholder_pass')}}" spellcheck="false" badinput="false" autocapitalize="off" value="{{ old('password') }}" required>

                <div class="wrapper-password">
                  <p class="password-message">
                    <span class="waiting-message">{{trans('register.password_validate_1')}}</span>
                    <span class="waiting-message">{{trans('register.password_validate_2')}}</span>
                    <span class="waiting-message">{{trans('register.password_validate_3')}}</span>
                    <span class="secure-message">{{trans('register.password_validate_4')}}</span>
                  </p>
                </div>
            </li>
        </ul>
    </fieldset>
    <fieldset>
        <ul class="field-group">
            <li class="field-item field-item__checkbox">
                <input name="accept_privacy_policies" type="checkbox" id="accept_privacy_policies" value="1" {{ (! empty(old('accept_privacy_policies')) ? 'checked' : '') }} required><span class="checkmark"></span>
                <label for="accept_privacy_policies">
                    {!! trans('register.accept_privacy_policies') !!}
                </label>
            </li>
            <li class="field-item field-item__checkbox">
                <input name="accept_promotions" type="checkbox" id="accept_promotions" value="1" {{ (! empty(old('accept_promotions')) ? 'checked' : '') }}>
                <span class="checkmark"></span>
                <label for="accept_promotions">{{trans('register.accept_promotions')}}</label>
            </li>
        </ul>
    </fieldset>
    @if(isset($errors) && count($errors->all()) > 0)
    <fieldset>
      <div class="form-message bounceIn dp-error"><div><p>
          @foreach ($errors->all() as $error)
              {{ $error }}
          @endforeach
          </p></div>
      </div>
    </fieldset>
    @endif
    <fieldset class="btn-login">
        <div class="g-recaptcha"
             data-sitekey="{{ env('RECAPTCHA_SITE_KEY') }}"
             data-size="invisible"
             data-callback="sendRegisterForm">
        </div>
        <button type="submit" class="dp-button button-medium primary-green button--round">{{trans('register.btn_create')}}</button>
    </fieldset>
</form>
<div class="content-legal" style="margin-top: 0px;">{!!trans('register.content-legal')!!}</div>
<footer>
    <small>
        <p>{!!trans('register.footer_small')!!}</p>
    </small>
</footer>
