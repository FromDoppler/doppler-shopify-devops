<div class="container">
  <header>
    <h1>Doppler for Shopify – Installation</h1>
    <p class="subhead">
      <label for="shop">Enter your shop domain to log in or install this app.</label>
    </p>
  </header>

  <div class="container__form">
    <form method="GET" action="/">
      <input type="text" name="shop" id="shop" placeholder="example.myshopify.com" required>
      <button type="submit">Install</button>
    </form>
  </div>
</div>

<style>
body, html {
  font-family: "ProximaNovaLight", "Helvetica Neue", Helvetica, Arial, sans-serif !important;
  background-color: #f2f7fa !important;
  height: auto;
}
.container {
    text-align: center;
    margin-top: 100px;
    padding: 20px;
}
h1 {
    font-weight: 300;
    font-size: 40px;
    margin-bottom: 10px;
}
.subhead label {
    font-size: 17px;
    line-height: 32px;
    font-weight: 300;
    color: #969A9C;
}
.container__form {
    width: 400px;
    margin: auto;
}
input {
    width: 300px;
    height: 50px;
    padding: 10px;
    border: 1px solid #479CCf;
    color: #575757;
    background-color: #ffffff;
    box-sizing: border-box;
    border-radius: 4px 0 0 4px;
    font-size: 18px;
    float: left;
}
button {
    color: #ffffff;
    background-color: #3793cb;
    width: 100px;
    height: 50px;
    padding: 10px 20px 10px 20px;
    box-sizing: border-box;
    border: none;
    text-shadow: 0 1px 0 #3188bc;
    font-size: 18px;
    cursor: pointer;
    border-radius: 0 4px 4px 0;
    float: right;
  }
</style>
