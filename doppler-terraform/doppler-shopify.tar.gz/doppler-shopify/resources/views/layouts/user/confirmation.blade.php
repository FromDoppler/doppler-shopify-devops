<link rel="stylesheet" href="https://use.typekit.net/fbq8dbp.css">

<div class="dp-c-dropdown language-selector">
    <button class="lang--{{$current_lang}}" id="menubutton" aria-haspopup="true" aria-controls="menu2">{{$current_lang}}</button>
    <ul id="menu2" role="menu" aria-labelledby="menubutton" tabindex="-1">
        <li role="none">
            <a role="menuitem" href="/confirmation?lang={{$secundary_lang}}&email={{$email}}" class="lang--{{$secundary_lang}}" tabindex="-1">{{$secundary_lang}}</a>
        </li>
    </ul>
</div>

<header>
    <div class="logo-doppler-new"><a target="_blank" href="https://www.fromdoppler.com/{{$current_lang}}/?utm_source=app&amp;utm_medium=landing&amp;utm_campaign=login" rel="noopener noreferrer">Doppler</a></div>
    <hr class="name-of-your-vertical-line"/>
    <div class="shopify-class">
        <img src="asset/images/a67335211.jpg" alt=""> <span>{{$shopname}}</span>
    </div>
</header>
<div class="confirmation">
    <span class="title">{!!trans('confirmation.tankyou')!!}</span>
    <span class="txt">{!!trans('confirmation.checkyour')!!}</span>
    <img class="env" src="/asset/images/envelope.svg">
    <span class="txt txt-mt">{!!trans('confirmation.note')!!}</span>
    @if(!isset($resentemail))
    <form method="POST" action="resendactivationemail?lang={{$current_lang}}" class="confirmation-form">
    {{csrf_field()}}
    <span class="txt txt-mt">{!!trans('confirmation.notreceived')!!} <a onclick="sendActivationEmail('{{$email}}')" href="javascript: void(0)">{!!trans('confirmation.resentit')!!}</a></span>

    @if(isset($errors) && count($errors->all()) > 0)
    <fieldset>
      <div class="form-message bounceIn dp-error"><div><p>
          @foreach ($errors->all() as $error)
              {{ $error }}
          @endforeach
          </p></div>
      </div>
    </fieldset>
    @endif

    </form>
    @endif
    @if(isset($resentemail))
    <span class="txt txt-mt">¿Aún no has recibido el Email? Ya te lo hemos reenviado, si no llega en los próximos minutos, por favor <a href="mailto:soporte@fromdoppler.com">contáctate con Soporte</a>.</span>
    @endif

    <span class="txt txt-mt">{!!trans('confirmation.footerprivacy')!!} <a href="https://www.fromdoppler.com/{{$current_lang}}/legal/privacidad?utm_source=app&utm_medium=landing&utm_campaign=signup">{!!trans('confirmation.footerprivacylink')!!}</a></span>
</div>

<style>
    .confirmation {
        font-family: "proxima-nova";
        color: #333333;
        text-align: center;
    }
    .confirmation .title {
        font-weight: bold;
        font-size: 35.5px;
        line-height: 40px;
        display: block;
        margin-bottom: 21px;
    }
    .confirmation .txt {
        font-size: 13px;
        line-height: 13px;
        display: block;
        max-width: 417px;
        margin: 0 auto;
    }
    .confirmation .txt-mt {
        margin-top: 46px;
    }
    .confirmation .env {
        width: 140px;
        margin-top: 28px;
        margin-right: -10px;
    }
    .confirmation a {
        color: #33AD73;
        text-decoration: none;
    }
    .confirmation a:hover {
        text-decoration: underline;
    }
</style>
