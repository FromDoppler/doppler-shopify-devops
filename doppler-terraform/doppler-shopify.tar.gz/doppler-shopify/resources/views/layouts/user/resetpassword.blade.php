<div class="dp-c-dropdown language-selector">
    <button class="lang--{{$current_lang}}" id="menubutton" aria-haspopup="true" aria-controls="menu2">{{$current_lang}}</button>
    <ul id="menu2" role="menu" aria-labelledby="menubutton" tabindex="-1">
        <li role="none">
            <a role="menuitem" href="/resetpassword?lang={{$secundary_lang}}" class="lang--{{$secundary_lang}}" tabindex="-1">{{$secundary_lang}}</a>
        </li>
    </ul>
</div>

<header>
    <div class="logo-doppler-new"><a target="_blank" href="https://www.fromdoppler.com/{{$current_lang}}/?utm_source=app&amp;utm_medium=landing&amp;utm_campaign=login" rel="noopener noreferrer">Doppler</a></div>
    <hr class="name-of-your-vertical-line"/>
    <div class="shopify-class">
        <img src="asset/images/a67335211.jpg" alt=""> <span>{{$shopname}}</span>
    </div>
</header>
<h1>{!!trans('resetpassword.tittle')!!}</h1>
<div align="center">
    <p class="content-subtitle">{!! trans('resetpassword.comment') !!}</p>
</div>

@if(!isset($responseok))
<form id="{{ getFormId() }}" method="POST" action="resetpassword?lang={{$current_lang}}" novalidate="true" onsubmit="return validateResetPasswordForm()" class="login-form">
  {{csrf_field()}}
    <fieldset>
        <ul class="field-group">
            <li class="field-item">
                <label for="email">{{trans('resetpassword.username')}}</label>
                <input type="email" name="email" id="email" maxlength="100" value="{{old('email')}}" required placeholder="{{trans('resetpassword.placeholder_user')}}">
            </li>
        </ul>
    </fieldset>
    @if(isset($errors) && count($errors->all()) > 0)
    <fieldset>
      <div class="form-message bounceIn dp-error"><div><p>
          @foreach ($errors->all() as $error)
              {{ $error }}
          @endforeach
          </p></div>
      </div>
    </fieldset>
    @endif
    <fieldset class="btn-login">
        <div class="g-recaptcha"
             data-sitekey="{{ env('RECAPTCHA_SITE_KEY') }}"
             data-size="invisible"
             data-callback="sendResetPasswordForm">
        </div>
        <button type="submit" class="dp-button button-medium primary-green button--round">{{trans('resetpassword.btn_login')}}</button>
        <a class="forgot-link" href="/login?lang={{$current_lang}}"><span class="triangle-right"></span>{{trans('resetpassword.btn_back')}}</a>
    </fieldset>
</form>
@else
<div class="sc-bwzfXH fvUtrW">
  <div class="form-message dp-ok-message bounceIn">
    <p>{{trans('resetpassword.ok_message_title')}}</p>
    <p>{{trans('resetpassword.ok_message_text')}}</p>
    <a class="forgot-link" href="/login?lang={{$current_lang}}"><span class="triangle-right"></span>{{trans('resetpassword.ok_message_back')}}</a>
  </div>
</div>
@endif
<footer>
    <div class="captcha-legal-message">
        <p>{!!trans('resetpassword.footer')!!}</p>
    </div>
    <small>
        <p>{!!trans('resetpassword.footer_small')!!}</p>
    </small>
</footer>
