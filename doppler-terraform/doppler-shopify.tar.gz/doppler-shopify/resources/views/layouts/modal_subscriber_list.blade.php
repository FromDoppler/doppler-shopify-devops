<!-- Modal -->
<div class="modal2 fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document" style="top: 10%;">
        <div class="styles_modal__gNwvD styles_modalCenter__L9F2w" role="dialog" aria-modal="true">
            <div>
                <div>
                    <div class="Polaris-Layout">
                        <div class="Polaris-Layout__Section">
                            <div class="Polaris-Card">
                                <div class="Polaris-Card__Header">
                                    <h2 class="Polaris-Heading">Create a new Doppler List</h2>
                                </div>
                                <div style="margin: 2rem;">
                                    <div class="Polaris-TextContainer Polaris-TextContainer--spacingLoose">
                                        <p>You can create a new Subscribers List from here, without needing to enter your account.</p>
                                        <form method="POST" action="/createSubscriptionList">
                                            {{csrf_field()}}
                                            <div class="">
                                                <div class="Polaris-Labelled__LabelWrapper">
                                                    <div class="Polaris-Label"><label id="TextField4Label" for="TextField4" class="Polaris-Label__Text">List Name</label></div>
                                                </div>
                                                <div class="Polaris-TextField">
                                                    <input type="text" id="subscriptionList" name="subscriptionList" placeholder="Write one that doesn’t exist yet" autocomplete="off" class="Polaris-TextField__Input">
                                                    <div class="Polaris-TextField__Backdrop"></div>
                                                </div>
                                            </div>
                                            <br>
                                            <div class="Polaris-Stack Polaris-Stack--distributionTrailing Polaris-Stack--alignmentCenter">
                                                <div class="Polaris-Stack__Item">
                                                    <div class="Polaris-ButtonGroup">
                                                        <div class="Polaris-ButtonGroup__Item"><button type="button" class="Polaris-Button" data-dismiss="modal"><span class="Polaris-Button__Content"><span>Cancel</span></span></button></div>
                                                        <div class="Polaris-ButtonGroup__Item"><button type="submit" class="Polaris-Button Polaris-Button--primary Polaris-Button"><span class="Polaris-Button__Content"><span>Create</span></span></button></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <input type="hidden" value="{{$isSetup}}" name="isSetup">
                                            <input type="hidden" value="{{$listConfigured ?? ''}}" name="listConfigured">
                                            <span class="Polaris-VisuallyHidden"><button type="submit" aria-hidden="true"></button></span>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .modal-header2 {
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-align: start;
        -ms-flex-align: start;
        align-items: flex-start;
        -webkit-box-pack: justify;
        -ms-flex-pack: justify;
        justify-content: space-between;
        padding: 1rem;
        border-bottom: 1px solid #e9ecef;
        border-top-left-radius: .3rem;
        border-top-right-radius: .3rem;
    }
    .modal-title2 {
        margin-bottom: 0;
        line-height: 1.5;
    }
    .modal2 {
        background: rgba(0, 0, 0, 0.75);
        position: fixed;
        top: 0%;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: 1050;
        display: none;
        -webkit-overflow-scrolling: touch;
        outline: 0;
    }
</style>
