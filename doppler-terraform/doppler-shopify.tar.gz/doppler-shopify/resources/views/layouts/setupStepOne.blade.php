<div class="polaris-progress">
    <progress class="polaris-progress__progress" value="50" max="100"></progress>
    <div class="polaris-progress__bar" style="width:25%"></div>
</div>
<div id="root">
    <div class="Polaris-Page">
        <div class="Polaris-Page__Content">
            <div class="Polaris-Layout">
                <div class="Polaris-Layout__Section">
                    <div style="margin-top: 2rem;">
                        <div class="Polaris-TextContainer Polaris-TextContainer--spacingLoose">
                            <p class="Polaris-DisplayText Polaris-DisplayText--sizeLarge">Connect your Shopify store to your Doppler account</p>
                            <br>
                            <span class="Polaris-TextStyle--variationSubdued">
                        <p class="Polaris-DisplayText Polaris-DisplayText--sizeSmall">Follow a few steps to connect both platforms and add customers and their purchase data automatically to Doppler, import your store products into Email Templates and create Abandoned Cart and Retargeting Product Automations. To start, please use your Doppler account or create one if you haven't yet.<br>You need a paid account to connect with Shopify.</p>
                     </span>
                        </div>
                    </div>
                    <div style="margin-top: 2rem;">
                        <div class="Polaris-ButtonGroup">
                            <div class="Polaris-ButtonGroup__Item"><a class="Polaris-Button Polaris-Button--primary" href="/login" role="button">Connect existing account</a></div>
                            <div class="Polaris-ButtonGroup__Item"><a class="Polaris-Button" href="/register" rel="noopener noreferrer" data-polaris-unstyled="true"><span class="Polaris-Button__Content"><span>Sign up now</span></span></a></div>
                        </div>
                    </div>
                </div>
                <div class="Polaris-Layout__Section Polaris-Layout__Section--secondary"><img src="/asset/images/connect.svg" style="max-width: 30rem;"></div>
            </div>
        </div>
    </div>
</div>
