<div class="polaris-progress">
    <progress class="polaris-progress__progress" value="50" max="100"></progress>
    <div class="polaris-progress__bar" style="width:50%"></div>
</div>
