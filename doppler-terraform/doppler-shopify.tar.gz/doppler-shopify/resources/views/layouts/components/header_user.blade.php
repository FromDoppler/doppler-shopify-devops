<header>
    <div class="logo-doppler-new"><a target="_blank" href="https://www.fromdoppler.com/{{$current_lang}}/?utm_source=app&amp;utm_medium=landing&amp;utm_campaign=login" rel="noopener noreferrer">Doppler</a></div>
    <hr class="name-of-your-vertical-line"/>
    <div class="shopify-class">
        <img src="asset/images/a67335211.jpg" alt=""> <span>{{$shopname}}</span>
    </div>
</header>
