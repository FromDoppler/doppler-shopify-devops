<div class="dp-c-dropdown language-selector">
    <button class="lang--{{$current_lang}}" id="menubutton" aria-haspopup="true" aria-controls="menu2">{{$current_lang}}</button>
    <ul id="menu2" role="menu" aria-labelledby="menubutton" tabindex="-1">
        <li role="none">
            <a role="menuitem" href="/{{$urlCallbackLang}}?lang={{$secundary_lang}}" class="lang--{{$secundary_lang}}" tabindex="-1">{{$secundary_lang}}</a>
        </li>
    </ul>
</div>
