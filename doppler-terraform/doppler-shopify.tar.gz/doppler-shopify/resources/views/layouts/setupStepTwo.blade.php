@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
<div class="polaris-progress">
    <progress class="polaris-progress__progress" value="50" max="100"></progress>
    <div class="polaris-progress__bar" style="width:50%"></div>
</div>
<div id="root">
    <div class="Polaris-Page">
        <div class="Polaris-Page__Content">
            <div class="Polaris-Layout">
                <div class="Polaris-Layout__Section">
                    <div class="Polaris-Stack Polaris-Stack--vertical Polaris-Stack--distributionFill">
                        <div class="Polaris-Stack__Item">
                            <div class="Polaris-Card">
                                <div class="Polaris-Stack Polaris-Stack--vertical Polaris-Stack--spacingTight Polaris-Stack--distributionFill Polaris-Stack--alignmentCenter">
                                    <div class="Polaris-Stack__Item"><img src="/asset/images/integration.png" style="margin-top: 2rem;"></div>
                                    <div class="Polaris-Stack__Item">
                                        <div class="Polaris-TextContainer"><b class="Polaris-TextStyle--variationStrong">Connect</b> Doppler <b class="Polaris-TextStyle--variationStrong">to your Shopify account</b></div>
                                    </div>
                                    <div class="Polaris-Stack__Item">
                                        <div class="Polaris-TextContainer"><span class="Polaris-TextStyle--variationSubdued">Doppler is a free application that connects your</span></div>
                                    </div>
                                    <div class="Polaris-Stack__Item">
                                        <div class="Polaris-TextContainer"><span class="Polaris-TextStyle--variationSubdued">Shopify store with your Doppler account.</span></div>
                                    </div>
                                    <div class="Polaris-Stack__Item">
                                        <div style="min-width: 40rem; margin-top: 2rem; margin-bottom: 2rem;">
                                            <div class="Polaris-FormLayout">
                                                <div class="Polaris-FormLayout__Item">
                                                    <form method="POST" action="/setupApp">
                                                        {{csrf_field()}}
                                                        <div class="">
                                                            <div class="Polaris-Labelled__LabelWrapper">
                                                                <div class="Polaris-Label"><label id="account" for="account" class="Polaris-Label__Text">Username</label></div>
                                                            </div>
                                                            <div class="Polaris-TextField">
                                                                <input id="account" name="account" placeholder="Psst! It's your Email" autocomplete="off" class="Polaris-TextField__Input" type="email" aria-label="Username" aria-labelledby="TextField1Label" aria-invalid="false" value="">
                                                                <div class="Polaris-TextField__Backdrop"></div>
                                                            </div>
                                                        </div>
                                                        <br>
                                                        <div class="">
                                                            <div class="Polaris-Labelled__LabelWrapper">
                                                                <div class="Polaris-Label"><label id="api_key" for="api_key" class="Polaris-Label__Text">API Key</label></div>
                                                            </div>
                                                            <div class="Polaris-TextField">
                                                                <input id="api_key" name="api_key" placeholder="e.g.: C22CADA13759DB9BBDF93B9D87C14D5A" autocomplete="off" class="Polaris-TextField__Input" aria-label="API Key" aria-labelledby="TextField2Label" aria-invalid="false" value="">
                                                                <div class="Polaris-TextField__Backdrop"></div>
                                                            </div>
                                                        </div>
                                                        <br>
                                                        <div class="Polaris-Stack Polaris-Stack--distributionTrailing Polaris-Stack--alignmentFill">
                                                            <div class="Polaris-Stack__Item"><button type="submit" class="Polaris-Button Polaris-Button--primary Polaris-Button"><span class="Polaris-Button__Content"><span>Connect</span></span></button></div>
                                                        </div>
                                                        <span class="Polaris-VisuallyHidden"><button type="submit" aria-hidden="true"></button></span>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="Polaris-Stack__Item">
                            <div class="Polaris-FooterHelp">
                                <div class="Polaris-FooterHelp__Content">
                                    <div class="Polaris-FooterHelp__Icon">
                              <span class="Polaris-Icon Polaris-Icon--colorTeal Polaris-Icon--isColored Polaris-Icon--hasBackdrop">
                                 <svg class="Polaris-Icon__Svg" viewBox="0 0 20 20" focusable="false" aria-hidden="true">
                                    <circle cx="10" cy="10" r="9" fill="currentColor"></circle>
                                    <path d="M10 0C4.486 0 0 4.486 0 10s4.486 10 10 10 10-4.486 10-10S15.514 0 10 0m0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8 8 3.589 8 8-3.589 8-8 8m0-4a1 1 0 1 0 0 2 1 1 0 1 0 0-2m0-10C8.346 4 7 5.346 7 7a1 1 0 1 0 2 0 1.001 1.001 0 1 1 1.591.808C9.58 8.548 9 9.616 9 10.737V11a1 1 0 1 0 2 0v-.263c0-.653.484-1.105.773-1.317A3.013 3.013 0 0 0 13 7c0-1.654-1.346-3-3-3"></path>
                                 </svg>
                              </span>
                                    </div>
                                    <div class="Polaris-FooterHelp__Text">Learn where to find your <a target="_blank" class="Polaris-Link" href="https://help.fromdoppler.com/en/where-do-i-find-my-api-key/?utm_source=integracion&amp;utm_medium=integracion&amp;utm_campaign=shopify" rel="noopener noreferrer" data-polaris-unstyled="true">API Key</a>.</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
