<!-- Modal -->
<div class="modal2 fade" id="myModalInvalidList" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document" style="top: 10%;">
        <div class="styles_modal__gNwvD styles_modalCenter__L9F2w" role="dialog" aria-modal="true">
            <div>
                <div class="Polaris-Layout">
                    <div class="Polaris-Layout__Section">
                        <div class="Polaris-Card">
                            <div class="Polaris-Card__Header">
                                <h2 class="Polaris-Heading">Invalid List</h2>
                            </div>
                            <div class="Polaris-Card__Section">
                                <p>Your list has been removed. Select a new list.</p>
                                <br>
                                <div class="Polaris-Stack Polaris-Stack--distributionTrailing Polaris-Stack--alignmentCenter">
                                    <div class="Polaris-Stack__Item">
                                        <div class="Polaris-ButtonGroup">
                                            <div class="Polaris-ButtonGroup__Item"><button data-dismiss="modal" onclick="redirectStepThree()" class="Polaris-Button Polaris-Button--primary"><span class="Polaris-Button__Content"><span>Accept</span></span></button></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .modal-header2 {
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-align: start;
        -ms-flex-align: start;
        align-items: flex-start;
        -webkit-box-pack: justify;
        -ms-flex-pack: justify;
        justify-content: space-between;
        padding: 1rem;
        border-bottom: 1px solid #e9ecef;
        border-top-left-radius: .3rem;
        border-top-right-radius: .3rem;
    }
    .modal-title2 {
        margin-bottom: 0;
        line-height: 1.5;
    }
    .modal2 {
        background: rgba(0, 0, 0, 0.75);
        position: fixed;
        top: 0%;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: 1050;
        display: none;
        -webkit-overflow-scrolling: touch;
        outline: 0;
    }
</style>
