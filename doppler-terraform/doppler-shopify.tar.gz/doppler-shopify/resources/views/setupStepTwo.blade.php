@extends('template')
@section('content')
    @include('layouts.setupStepTwo')
@endsection
