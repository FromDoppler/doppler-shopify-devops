@extends('template')
@section('content')
    @include('layouts/user/install')
@endsection
